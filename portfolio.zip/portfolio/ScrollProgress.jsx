import { motion, useScroll, useSpring } from "framer-motion";

export default function ScrollProgress() {
  const { scrollYProgress } = useScroll();
  const scaleX = useSpring(scrollYProgress, { stiffness: 120, damping: 20 });
  return (
    <motion.div
      data-testid="scroll-progress"
      style={{ scaleX }}
      className="fixed top-0 left-0 right-0 h-[3px] origin-left z-[60]"
    >
      <div
        className="w-full h-full"
        style={{
          background:
            "linear-gradient(90deg, #00FF6A 0%, #00E08A 40%, #00C471 100%)",
          boxShadow: "0 0 12px rgba(0,255,106,0.6)",
        }}
      />
    </motion.div>
  );
}
