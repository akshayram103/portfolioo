import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Star, Quote } from "lucide-react";
import { TESTIMONIALS } from "@/data/portfolioData";

export default function Testimonials() {
  const [index, setIndex] = useState(0);

  useEffect(() => {
    const id = setInterval(() => {
      setIndex((i) => (i + 1) % TESTIMONIALS.length);
    }, 5500);
    return () => clearInterval(id);
  }, []);

  const t = TESTIMONIALS[index];

  return (
    <section id="testimonials" className="section relative" data-testid="testimonials-section">
      <div className="orb" style={{ bottom: "5%", right: "-5%", width: 340, height: 340, background: "radial-gradient(circle, #a855f7, transparent 60%)" }} />
      <div className="container-x relative">
        <div className="max-w-2xl">
          <span className="chip">Testimonials</span>
          <h2 className="font-display font-bold text-4xl sm:text-5xl mt-4">
            Words from <span className="text-gradient-accent">creators & clients</span>.
          </h2>
        </div>

        <div className="mt-12 grid lg:grid-cols-12 gap-6">
          {/* Featured slide */}
          <div className="lg:col-span-7 relative">
            <div className="surface-glass p-8 md:p-10 min-h-[300px] relative overflow-hidden">
              <Quote className="absolute -top-2 -left-2 w-24 h-24 text-white/[0.04]" strokeWidth={1} />
              <AnimatePresence mode="wait">
                <motion.div
                  key={index}
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -20 }}
                  transition={{ duration: 0.4 }}
                >
                  <div className="flex items-center gap-1">
                    {Array.from({ length: t.stars }).map((_, i) => (
                      <Star key={i} className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                    ))}
                  </div>
                  <p className="mt-5 font-display text-2xl md:text-3xl leading-snug text-white">
                    &ldquo;{t.quote}&rdquo;
                  </p>
                  <div className="mt-6 flex items-center gap-3">
                    <div
                      className="w-11 h-11 rounded-full flex items-center justify-center font-display font-bold"
                      style={{ background: "linear-gradient(135deg,#00FF6A,#00C471)" }}
                    >
                      {t.name.charAt(0)}
                    </div>
                    <div>
                      <div className="font-semibold">{t.name}</div>
                      <div className="text-sm text-slate-400">{t.role}</div>
                    </div>
                  </div>
                </motion.div>
              </AnimatePresence>
              <div className="mt-8 flex gap-2">
                {TESTIMONIALS.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setIndex(i)}
                    data-testid={`testimonial-dot-${i}`}
                    className={`h-1.5 rounded-full transition-all ${
                      i === index ? "w-8 bg-white" : "w-2 bg-white/30"
                    }`}
                    aria-label={`Testimonial ${i + 1}`}
                  />
                ))}
              </div>
            </div>
          </div>

          {/* Stacked mini cards */}
          <div className="lg:col-span-5 grid sm:grid-cols-2 gap-4 self-start">
            {TESTIMONIALS.map((mini, i) => (
              <motion.button
                key={mini.name}
                onClick={() => setIndex(i)}
                whileHover={{ y: -4 }}
                className={`surface-card p-5 text-left transition-all ${
                  i === index ? "ring-1 ring-[#7c3aed]/60" : ""
                }`}
                data-testid={`testimonial-mini-${i}`}
              >
                <div className="flex items-center gap-1 mb-3">
                  {Array.from({ length: mini.stars }).map((_, j) => (
                    <Star key={j} className="w-3.5 h-3.5 fill-yellow-400 text-yellow-400" />
                  ))}
                </div>
                <p className="text-sm text-slate-300 line-clamp-3">&ldquo;{mini.quote}&rdquo;</p>
                <div className="mt-3 text-xs text-slate-500">— {mini.name}</div>
              </motion.button>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
