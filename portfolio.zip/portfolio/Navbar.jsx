import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Menu, X, Sun, Moon } from "lucide-react";
import { NAV_LINKS } from "@/data/portfolioData";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [dark, setDark] = useState(true);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const root = document.documentElement;
    if (dark) root.classList.remove("light");
    else root.classList.add("light");
  }, [dark]);

  const go = (id) => {
    setOpen(false);
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  return (
    <>
      <motion.header
        initial={{ y: -30, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.6 }}
        className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
          scrolled
            ? "backdrop-blur-xl bg-[rgba(11,15,25,0.7)] border-b border-white/5"
            : "bg-transparent"
        }`}
        data-testid="site-navbar"
      >
        <nav className="container-x flex items-center justify-between py-4">
          <a
            href="#home"
            onClick={(e) => {
              e.preventDefault();
              go("home");
            }}
            className="font-display font-bold text-lg tracking-tight"
            data-testid="nav-brand"
          >
            <span className="text-gradient-accent">akshayram</span>
          </a>

          <ul className="hidden lg:flex items-center gap-1">
            {NAV_LINKS.map((l) => (
              <li key={l.id}>
                <button
                  data-testid={`nav-${l.id}`}
                  onClick={() => go(l.id)}
                  className="px-3 py-2 rounded-full text-sm text-slate-300 hover:text-white transition-colors relative group"
                >
                  <span>{l.label}</span>
                  <span className="absolute left-3 right-3 -bottom-0.5 h-px bg-gradient-to-r from-[#00FF6A] to-[#00C471] scale-x-0 group-hover:scale-x-100 transition-transform origin-left" />
                </button>
              </li>
            ))}
          </ul>

          <div className="flex items-center gap-2">
            <button
              data-testid="theme-toggle-btn"
              onClick={() => setDark((d) => !d)}
              className="h-10 w-10 rounded-full flex items-center justify-center surface-glass"
              aria-label="Toggle theme"
            >
              {dark ? (
                <Sun className="w-4 h-4 text-yellow-300" />
              ) : (
                <Moon className="w-4 h-4 text-slate-700" />
              )}
            </button>
            <button
              data-testid="nav-hire-btn"
              onClick={() => go("contact")}
              className="hidden md:inline-flex btn-primary text-sm py-2.5 px-5"
            >
              Hire Me
            </button>
            <button
              data-testid="nav-menu-btn"
              onClick={() => setOpen((o) => !o)}
              className="lg:hidden h-10 w-10 rounded-full flex items-center justify-center surface-glass"
              aria-label="Menu"
            >
              {open ? (
                <X className="w-5 h-5 text-white" />
              ) : (
                <Menu className="w-5 h-5 text-white" />
              )}
            </button>
          </div>
        </nav>
      </motion.header>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, y: -20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -20 }}
            className="fixed top-[68px] left-0 right-0 z-40 lg:hidden"
          >
            <div className="container-x">
              <div className="surface-glass p-4">
                <ul className="grid grid-cols-2 gap-1">
                  {NAV_LINKS.map((l) => (
                    <li key={l.id}>
                      <button
                        data-testid={`nav-mobile-${l.id}`}
                        onClick={() => go(l.id)}
                        className="w-full text-left px-4 py-3 rounded-xl text-slate-200 hover:bg-white/5"
                      >
                        {l.label}
                      </button>
                    </li>
                  ))}
                </ul>
              </div>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
