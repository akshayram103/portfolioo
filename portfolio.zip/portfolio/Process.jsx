import { motion } from "framer-motion";
import { PROCESS_STEPS } from "@/data/portfolioData";

export default function Process() {
  return (
    <section id="process" className="section relative" data-testid="process-section">
      <div className="orb" style={{ top: "20%", left: "-6%", width: 300, height: 300, background: "radial-gradient(circle, #00C471, transparent 65%)" }} />
      <div className="container-x relative">
        <div className="max-w-2xl">
          <span className="chip">Editing Process</span>
          <h2 className="font-display font-bold text-4xl sm:text-5xl mt-4">
            From <span className="text-gradient-accent">raw clip</span> to final cut.
          </h2>
          <p className="mt-4 text-slate-400">
            A structured 9-step workflow ensuring every project ships with cinema-grade quality
            and on-time delivery.
          </p>
        </div>

        <div className="mt-14 grid md:grid-cols-3 gap-5">
          {PROCESS_STEPS.map((step, i) => (
            <motion.div
              key={step.title}
              initial={{ opacity: 0, y: 22 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ duration: 0.5, delay: (i % 3) * 0.08 }}
              className="surface-card p-6 relative overflow-hidden group"
            >
              <div className="flex items-center gap-4">
                <div
                  className="w-14 h-14 rounded-2xl flex items-center justify-center font-display font-bold text-2xl"
                  style={{
                    background: "linear-gradient(135deg, rgba(124,58,237,0.15), rgba(6,182,212,0.10))",
                    border: "1px solid rgba(255,255,255,0.08)",
                    color: "#e2e8f0",
                  }}
                >
                  {String(i + 1).padStart(2, "0")}
                </div>
                <div>
                  <div className="text-xs uppercase tracking-[0.28em] text-slate-500">
                    Step
                  </div>
                  <h3 className="font-display text-lg font-semibold">{step.title}</h3>
                </div>
              </div>
              <p className="mt-4 text-sm text-slate-400 leading-relaxed">{step.desc}</p>
              <div
                className="absolute inset-x-0 -bottom-0.5 h-0.5 opacity-0 group-hover:opacity-100 transition-opacity"
                style={{
                    background:
                    "linear-gradient(90deg, transparent, #00FF6A, #00C471, transparent)",
                }}
              />
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
