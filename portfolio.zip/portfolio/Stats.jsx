import { motion } from "framer-motion";
import Counter from "@/components/portfolio/Counter";
import { HERO_STATS } from "@/data/portfolioData";

export default function Stats() {
  return (
    <section className="section !py-20" data-testid="stats-section">
      <div className="container-x">
        <div className="surface-glass p-8 md:p-12">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {HERO_STATS.map((s, i) => (
              <motion.div
                key={s.label}
                initial={{ opacity: 0, y: 16 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.1 }}
                className="text-center md:text-left"
              >
                <div className="font-display text-4xl sm:text-5xl font-extrabold text-gradient">
                  <Counter to={s.value} suffix={s.suffix} decimals={s.decimals || 0} />
                </div>
                <div className="mt-2 text-[11px] uppercase tracking-[0.28em] text-slate-400">
                  {s.label}
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
