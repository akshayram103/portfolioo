import cv2
import numpy as np

def main():
    mockup_path = r'C:\Users\akshy\.gemini\antigravity-ide\brain\6e605ea1-d7d9-4c82-a8a8-b6b7a57b8311\media__1786096908143.png'
    ui_path = r'C:\Users\akshy\.gemini\antigravity-ide\brain\6e605ea1-d7d9-4c82-a8a8-b6b7a57b8311\media__1786092650655.png'

    background = cv2.imread(mockup_path)
    screen_img = cv2.imread(ui_path)

    if background is None or screen_img is None:
        print('Error reading image files')
        return

    h, w, _ = background.shape
    sh, sw, _ = screen_img.shape

    # Destination quad corners in mockup (Top-Left, Top-Right, Bottom-Right, Bottom-Left)
    dst_pts = np.array([
        [601, 23],
        [961, 244],
        [897, 561],
        [555, 326]
    ], dtype=np.float32)

    src_pts = np.array([
        [0, 0],
        [sw, 0],
        [sw, sh],
        [0, sh]
    ], dtype=np.float32)

    matrix = cv2.getPerspectiveTransform(src_pts, dst_pts)
    warped = cv2.warpPerspective(screen_img, matrix, (w, h), flags=cv2.INTER_LANCZOS4)

    # Create smooth blended mask
    mask = np.zeros((h, w), dtype=np.uint8)
    cv2.fillConvexPoly(mask, dst_pts.astype(np.int32), 255)
    mask_blur = cv2.GaussianBlur(mask, (3, 3), 0)
    alpha = (mask_blur / 255.0)[:, :, np.newaxis]

    result = (warped * alpha + background * (1.0 - alpha)).astype(np.uint8)
    cv2.imwrite('assets/images/project1.jpg', result)
    print('Successfully generated 3D composited laptop image for Project 1')

if __name__ == '__main__':
    main()
