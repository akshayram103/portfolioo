import { useEffect, useRef } from "react";
import { motion, useScroll, useTransform } from "framer-motion";
import { Play, Download, ArrowRight } from "lucide-react";
import Counter from "@/components/portfolio/Counter";
import MagneticButton from "@/components/portfolio/MagneticButton";
import { HERO_STATS, HERO_VIDEO, HERO_POSTER } from "@/data/portfolioData";

export default function Hero() {
  const ref = useRef(null);
  const videoRef = useRef(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });
  const y = useTransform(scrollYProgress, [0, 1], [0, 180]);
  const opacity = useTransform(scrollYProgress, [0, 0.8], [1, 0.15]);

  useEffect(() => {
    if (videoRef.current) {
      videoRef.current.play().catch(() => {});
    }
  }, []);

  const go = (id) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <section
      id="home"
      ref={ref}
      className="relative min-h-[100svh] flex items-center overflow-hidden pt-24"
      data-testid="hero-section"
    >
      {/* Parallax video background */}
      <motion.div style={{ y, opacity }} className="absolute inset-0 z-0">
        <video
          ref={videoRef}
          className="absolute inset-0 w-full h-full object-cover"
          src={HERO_VIDEO}
          poster={HERO_POSTER}
          muted
          loop
          playsInline
          autoPlay
          preload="metadata"
        />
        <div
          className="absolute inset-0"
          style={{
            background:
              "linear-gradient(180deg, rgba(11,15,25,0.55) 0%, rgba(11,15,25,0.85) 60%, #0b0f19 100%)",
          }}
        />
        <div className="absolute inset-0 opacity-40" style={{
          background:
            "radial-gradient(600px 300px at 15% 20%, rgba(124,58,237,0.5), transparent 60%), radial-gradient(500px 260px at 80% 10%, rgba(6,182,212,0.35), transparent 60%)",
        }} />
      </motion.div>

      {/* Content */}
      <div className="container-x relative z-10">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.5, duration: 0.6 }}
          className="mb-6"
        >
          <span className="chip">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 shadow-[0_0_10px_rgba(52,211,153,0.9)]" />
            Available for new projects · 2026
          </span>
        </motion.div>

        <motion.h1
          initial={{ opacity: 0, y: 30 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.6, duration: 0.8, ease: "easeOut" }}
          className="font-display font-extrabold text-4xl sm:text-6xl lg:text-[92px] leading-[0.95] tracking-tight"
          data-testid="hero-title"
        >
          <span className="text-gradient-accent">akshayram</span>
        </motion.h1>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 1.85, duration: 0.7 }}
          className="mt-6 flex flex-wrap items-center gap-2 text-lg text-slate-200 font-display"
        >
          <span>Professional Video Editor</span>
          <span className="text-slate-600">·</span>
          <span className="text-gradient-accent font-semibold">CapCut Specialist</span>
          <span className="text-slate-600">·</span>
          <span>Social Media Content Creator</span>
        </motion.div>

        <motion.p
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 2.05, duration: 0.7 }}
          className="mt-6 max-w-2xl text-base sm:text-lg text-slate-400 leading-relaxed"
        >
          I help brands, creators and businesses create visually engaging content that
          increases audience engagement and leaves a lasting impression. With over 2.5
          years of experience I specialize in high-retention short-form videos, cinematic
          edits, promotional videos and social media content.
        </motion.p>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 2.25, duration: 0.7 }}
          className="mt-10 flex flex-wrap items-center gap-4"
        >
          <MagneticButton
            testid="hero-view-portfolio-btn"
            onClick={() => go("portfolio")}
            className="btn-primary"
          >
            View Portfolio <ArrowRight className="w-4 h-4" />
          </MagneticButton>
          <MagneticButton
            testid="hero-hire-me-btn"
            onClick={() => go("contact")}
            className="btn-outline-accent"
          >
            <Play className="w-4 h-4" /> Hire Me
          </MagneticButton>
          <MagneticButton
            testid="hero-download-resume-btn"
            as="a"
            href="#"
            onClick={(e) => e.preventDefault()}
            className="btn-ghost"
          >
            <Download className="w-4 h-4" /> Download Resume
          </MagneticButton>
        </motion.div>

        {/* Stats */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 2.45, duration: 0.8 }}
          className="mt-16 grid grid-cols-2 md:grid-cols-4 gap-4"
          data-testid="hero-stats"
        >
          {HERO_STATS.map((s, i) => (
            <div
              key={s.label}
              className="surface-glass p-5"
              style={{ boxShadow: i % 2 ? "0 0 40px rgba(6,182,212,0.08)" : "0 0 40px rgba(124,58,237,0.08)" }}
            >
              <div className="font-display text-3xl sm:text-4xl font-bold text-gradient">
                <Counter to={s.value} suffix={s.suffix} decimals={s.decimals || 0} />
              </div>
              <div className="mt-1 text-xs uppercase tracking-[0.18em] text-slate-400">
                {s.label}
              </div>
            </div>
          ))}
        </motion.div>
      </div>

      {/* Scroll indicator */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 3 }}
        className="absolute bottom-6 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2 z-10 hidden md:flex"
      >
        <span className="text-[10px] uppercase tracking-[0.4em] text-slate-500">Scroll</span>
        <div className="w-px h-10 bg-gradient-to-b from-slate-400 to-transparent" />
      </motion.div>
    </section>
  );
}
