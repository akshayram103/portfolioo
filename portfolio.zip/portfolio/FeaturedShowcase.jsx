import { useRef, useState } from "react";
import { motion } from "framer-motion";
import { Play, Pause } from "lucide-react";
import { FEATURED } from "@/data/portfolioData";

export default function FeaturedShowcase() {
  const videoRef = useRef(null);
  const [playing, setPlaying] = useState(false);

  const toggle = () => {
    if (!videoRef.current) return;
    if (playing) videoRef.current.pause();
    else videoRef.current.play().catch(() => {});
    setPlaying(!playing);
  };

  return (
    <section className="section" data-testid="featured-showcase">
      <div className="container-x">
        <div className="flex items-end justify-between flex-wrap gap-4 mb-10">
          <div>
            <span className="chip">Featured Showcase</span>
            <h2 className="font-display font-bold text-4xl sm:text-5xl mt-4">
              {FEATURED.title}
            </h2>
            <p className="mt-3 text-slate-400 max-w-xl">{FEATURED.subtitle}</p>
          </div>
          <div className="flex gap-2">
            {FEATURED.tech.map((t) => (
              <span
                key={t}
                className="px-3 py-1.5 rounded-full text-xs border border-white/10 bg-white/[0.04] text-slate-200"
              >
                {t}
              </span>
            ))}
          </div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7 }}
          className="grid lg:grid-cols-12 gap-8"
        >
          {/* Video */}
          <div className="lg:col-span-8 relative">
            <div className="gradient-border overflow-hidden aspect-video relative">
              <video
                ref={videoRef}
                src={FEATURED.preview}
                poster={FEATURED.poster}
                muted
                loop
                playsInline
                className="w-full h-full object-cover"
              />
              <button
                onClick={toggle}
                data-testid="featured-play-btn"
                className="absolute inset-0 flex items-center justify-center bg-gradient-to-t from-black/50 via-transparent to-transparent group"
              >
                <motion.span
                  whileHover={{ scale: 1.08 }}
                  className="h-16 w-16 rounded-full flex items-center justify-center"
                  style={{
                    background:
                      "linear-gradient(135deg, rgba(124,58,237,0.9), rgba(6,182,212,0.9))",
                    boxShadow: "0 12px 40px rgba(124,58,237,0.5)",
                  }}
                >
                  {playing ? (
                    <Pause className="w-6 h-6 text-white" />
                  ) : (
                    <Play className="w-6 h-6 text-white pl-1" />
                  )}
                </motion.span>
              </button>
            </div>
          </div>

          {/* Details */}
          <div className="lg:col-span-4 space-y-6">
            <div className="surface-card p-6">
              <h3 className="font-display text-lg font-semibold">Project</h3>
              <p className="mt-2 text-sm text-slate-300 leading-relaxed">
                {FEATURED.description}
              </p>
            </div>
            <div className="surface-card p-6">
              <h3 className="font-display text-lg font-semibold">Editing Process</h3>
              <ol className="mt-3 space-y-2 text-sm text-slate-300">
                {FEATURED.process.map((p, i) => (
                  <li key={p} className="flex items-start gap-3">
                    <span className="mt-0.5 h-5 w-5 rounded-full flex items-center justify-center text-[11px] font-bold bg-gradient-to-br from-[#00FF6A] to-[#00C471]">
                      {i + 1}
                    </span>
                    {p}
                  </li>
                ))}
              </ol>
            </div>
            <div className="surface-glass p-6 border border-white/10">
              <h3 className="font-display text-lg font-semibold text-gradient-accent">
                Client Feedback
              </h3>
              <p className="mt-3 text-sm text-slate-200 italic leading-relaxed">
                {FEATURED.feedback}
              </p>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
