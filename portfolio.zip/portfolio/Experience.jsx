import { motion } from "framer-motion";
import { Briefcase, CheckCircle2 } from "lucide-react";
import { EXPERIENCE } from "@/data/portfolioData";

export default function Experience() {
  return (
    <section id="experience" className="section" data-testid="experience-section">
      <div className="container-x">
        <div className="max-w-2xl">
          <span className="chip">Experience</span>
          <h2 className="font-display font-bold text-4xl sm:text-5xl mt-4">
            The work I&apos;ve <span className="text-gradient-accent">shipped</span>.
          </h2>
        </div>

        <div className="mt-12 grid lg:grid-cols-12 gap-8">
          {EXPERIENCE.map((exp, i) => (
            <motion.div
              key={exp.role}
              initial={{ opacity: 0, y: 26 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.1 }}
              className="lg:col-span-12 surface-card p-8 md:p-10"
            >
              <div className="flex flex-wrap items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div
                    className="w-14 h-14 rounded-2xl flex items-center justify-center"
                    style={{
                      background: "linear-gradient(135deg, #00FF6A, #00C471)",
                      boxShadow: "0 12px 40px rgba(0,255,106,0.35)",
                    }}
                  >
                    <Briefcase className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <h3 className="font-display text-2xl font-semibold">{exp.role}</h3>
                    <div className="text-slate-400 text-sm">{exp.period}</div>
                  </div>
                </div>
                <span className="chip">100+ Projects Shipped</span>
              </div>
              <div className="mt-8 grid md:grid-cols-2 gap-3">
                {exp.bullets.map((b) => (
                  <div key={b} className="flex items-start gap-3 text-slate-200 text-sm">
                    <CheckCircle2 className="w-4 h-4 mt-0.5 text-[#22d3ee]" />
                    <span>{b}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
