/* ============================================
   AKSHAYRAM PORTFOLIO — 1-TO-1 MATCH ENGINE
   Matching Attached Screenshots & russellnumo.nl Live Site Architecture
   ============================================ */

const gsapEngine = window.gsap;
const threeEngine = window.THREE;

/* Helper: Split text into word spans for word-by-word staggered slide-in animations */
function splitTextIntoWords(element) {
  if (!element || element.dataset.split) return;
  element.dataset.split = 'true';
  const text = element.textContent.trim();
  const words = text.split(/\s+/);
  element.innerHTML = words.map(word => 
    `<span class="word-outer" style="display:inline-block; overflow:hidden; vertical-align:top;"><span class="word-inner" style="display:inline-block; transform:translateY(35px); opacity:0; will-change:transform,opacity;">${word}</span></span>&nbsp;`
  ).join('');
}
window.splitTextIntoWords = splitTextIntoWords;

/* ============================================
   1. ALWAYS VISIBLE DUAL CURSOR ENGINE WITH LERP
   ============================================ */
/* Custom Cursor Follower Removed as requested */

/* ============================================
   2. RUSSELL NUMO 8-BAR LOADER CURTAIN & PRELOADER
   ============================================ */
function initPreloaderSequence(onCompleteCallback) {
  const preloader = document.getElementById('preloader-screen');
  const counterEl = document.getElementById('preloader-counter');
  const centerDot = document.getElementById('center-dot');
  const curtain = document.getElementById('loader-curtain');

  if (!preloader || !counterEl || !curtain) {
    if (onCompleteCallback) onCompleteCallback();
    return;
  }

  let count = { val: 1 };

  gsapEngine.to(count, {
    val: 100,
    duration: 2.2,
    ease: 'power1.inOut',
    onUpdate: () => {
      counterEl.textContent = `${Math.floor(count.val)}%`;
    },
    onComplete: () => {
      // 1. Show center white dot at 100%
      if (centerDot) centerDot.classList.add('is-visible');

      // 2. Hide counter screen and slide up 8 curtain bars
      setTimeout(() => {
        preloader.classList.add('is-hidden');
        curtain.classList.add('hide');
        document.body.classList.remove('is-loading');

        if (onCompleteCallback) onCompleteCallback();
      }, 400);
    }
  });
}

/* ============================================
   3. SEAMLESS INFINITE MARQUEES
   ============================================ */
function initInfiniteMarquees() {
  const rows = document.querySelectorAll('.marquee-row');
  if (!rows.length) return;

  rows.forEach((row) => {
    const track = row.querySelector('.marquee-track');
    if (!track) return;

    const direction = row.getAttribute('data-direction') || 'left';

    // Duplicate track for 100% seamless infinite marquee loop
    const clone = track.cloneNode(true);
    row.appendChild(clone);

    const isLeft = direction === 'left';
    const startX = isLeft ? 0 : -track.offsetWidth;
    const endX = isLeft ? -track.offsetWidth : 0;

    const marqueeTl = gsapEngine.timeline({ repeat: -1 });

    marqueeTl.fromTo(row.children, 
      { x: startX },
      {
        x: endX,
        duration: 25,
        ease: 'none'
      }
    );

    // Hover Interaction: Pause ONLY THIS row on hover/touch
    row.addEventListener('mouseenter', () => marqueeTl.pause());
    row.addEventListener('mouseleave', () => marqueeTl.play());
    row.addEventListener('touchstart', () => marqueeTl.pause(), { passive: true });
    row.addEventListener('touchend', () => marqueeTl.play());
  });
}

/* ============================================
   4. HORIZONTAL SLICE DISPLACEMENT GLITCH (RUSSELL NUMO EXACT MATCH)
   The image splits into horizontal strips that shift left/right
   independently with RGB chromatic aberration on hover/touch.
   ============================================ */
function createGlitchEffect(box, canvas, img) {
  if (!box || !canvas || !img) return;

  if (typeof threeEngine === 'undefined') return;

  // Make static image visible as fallback until texture loads
  img.style.opacity = '1';

  const scene = new threeEngine.Scene();
  const camera = new threeEngine.OrthographicCamera(-1, 1, 1, -1, 0, 1);

  const renderer = new threeEngine.WebGLRenderer({
    canvas: canvas,
    alpha: true,
    antialias: true
  });
  renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));

  function resizeRenderer() {
    const width = box.clientWidth;
    const height = box.clientHeight;
    if (width > 0 && height > 0) {
      renderer.setSize(width, height);
    }
  }
  resizeRenderer();
  window.addEventListener('resize', resizeRenderer);

  // Load Image Texture into WebGL
  const loader = new threeEngine.TextureLoader();
  const texture = loader.load(img.src, () => {
    img.style.opacity = '1';
    resizeRenderer();
  });

  const vertexShader = `
    varying vec2 vUv;
    void main() {
      vUv = uv;
      gl_Position = vec4(position, 1.0);
    }
  `;

  // DYNAMIC FINE MICRO-SLICE RGB DISPLACEMENT & SNAPPY RESPONSIVE GLITCH SHADER
  const fragmentShader = `
    uniform sampler2D uTexture;
    uniform vec2 uMouse;
    uniform float uHover;
    uniform float uTime;
    varying vec2 vUv;

    // Pseudo-random hash generator
    float hash(vec2 p) {
      return fract(sin(dot(p, vec2(127.1, 311.7))) * 43758.5453123);
    }

    void main() {
      vec2 uv = vUv;

      // 1. DYNAMIC FAST GLITCH TIMING (20 FPS STEP JITTER + SNAPPY CONTINUOUS WAVE)
      float stepTime = floor(uTime * 20.0);
      float waveTime = uTime * 7.5;

      // 2. FINE & SMALL HORIZONTAL MICRO-SLICE DISPLACEMENT
      // Slices image into 64 fine horizontal micro-strips
      float numSlices = 64.0;
      float sliceId = floor(uv.y * numSlices);

      float sliceHash = hash(vec2(sliceId, stepTime));

      // Trigger shift on ~40% of fine micro-slices per frame
      float isGlitchSlice = step(0.58, sliceHash);
      float rawShift = (sliceHash - 0.5) * 2.0; // [-1.0, 1.0]

      // Controlled horizontal slice displacement (max 2.4% width shift)
      float sliceShift = rawShift * 0.024 * isGlitchSlice * uHover;

      // Snappy sine wave distortion across fine slices
      float wave = sin(sliceId * 2.2 + waveTime) * cos(sliceId * 1.2 - waveTime * 0.6);
      sliceShift += wave * 0.008 * uHover;

      // Localized touch proximity boost around cursor/touch point
      float distToTouch = length(uv - uMouse);
      float touchRadius = smoothstep(0.60, 0.0, distToTouch);
      sliceShift += (hash(vec2(uv.y * 140.0, stepTime)) - 0.5) * 0.016 * touchRadius * uHover;

      // Displaced UV coordinates
      vec2 displacedUv = vec2(uv.x + sliceShift, uv.y);

      // 3. CRISP RGB CHROMATIC SPLIT ALONG FINE MICRO-SLICES
      // Red & Cyan channel separation along slice boundaries
      float rgbSplit = (0.012 + abs(sliceShift) * 1.1 + touchRadius * 0.008) * uHover;

      vec2 redUv   = clamp(vec2(displacedUv.x + rgbSplit, displacedUv.y), 0.0, 1.0);
      vec2 greenUv = clamp(displacedUv, 0.0, 1.0);
      vec2 blueUv  = clamp(vec2(displacedUv.x - rgbSplit, displacedUv.y), 0.0, 1.0);

      float r = texture2D(uTexture, redUv).r;
      float g = texture2D(uTexture, greenUv).g;
      float b = texture2D(uTexture, blueUv).b;

      vec3 color = vec3(r, g, b);

      // Clean tone pop on touch/hover
      color = pow(color, vec3(0.94)) * (1.0 + 0.10 * uHover);

      // 4. FINE CRT SCANLINES & NOISE OVERLAY
      float scanline = sin(uv.y * 650.0 + uTime * 10.0) * 0.5 + 0.5;
      color *= (1.0 - scanline * 0.05 * uHover);

      // Fine digital micro noise
      float microNoise = hash(uv * 300.0 + uTime * 30.0);
      color += (microNoise - 0.5) * 0.022 * uHover;

      gl_FragColor = vec4(color, 1.0);
    }
  `;

  const uniforms = {
    uTexture: { value: texture },
    uMouse: { value: new threeEngine.Vector2(0.5, 0.5) },
    uHover: { value: 0.0 },
    uTime: { value: 0.0 }
  };

  const material = new threeEngine.ShaderMaterial({
    vertexShader: vertexShader,
    fragmentShader: fragmentShader,
    uniforms: uniforms,
    transparent: true
  });

  const geometry = new threeEngine.PlaneGeometry(2, 2);
  const mesh = new threeEngine.Mesh(geometry, material);
  scene.add(mesh);

  let targetHover = 0;

  function updateCoordinates(clientX, clientY) {
    const rect = box.getBoundingClientRect();
    const x = (clientX - rect.left) / rect.width;
    const y = 1.0 - (clientY - rect.top) / rect.height;
    uniforms.uMouse.value.set(
      Math.max(0, Math.min(1, x)),
      Math.max(0, Math.min(1, y))
    );
  }

  function startGlitch(clientX, clientY) {
    targetHover = 1.0;
    box.classList.add('is-glitching');
    if (clientX !== undefined && clientY !== undefined) {
      updateCoordinates(clientX, clientY);
    }
  }

  function moveGlitch(clientX, clientY) {
    if (targetHover > 0.05) {
      targetHover = 1.0;
      box.classList.add('is-glitching');
      if (clientX !== undefined && clientY !== undefined) {
        updateCoordinates(clientX, clientY);
      }
    }
  }

  function stopGlitch() {
    targetHover = 0.0;
    box.classList.remove('is-glitching');
  }

  // Desktop Mouse Listeners
  box.addEventListener('mouseenter', (e) => startGlitch(e.clientX, e.clientY));
  box.addEventListener('mousemove', (e) => moveGlitch(e.clientX, e.clientY));
  box.addEventListener('mouseleave', stopGlitch);

  // Mobile Touch Listeners (TOUCHSTART, TOUCHMOVE, TOUCHEND, TOUCHCANCEL)
  box.addEventListener('touchstart', (e) => {
    if (e.touches.length > 0) {
      startGlitch(e.touches[0].clientX, e.touches[0].clientY);
    }
  }, { passive: true });

  box.addEventListener('touchmove', (e) => {
    if (e.touches.length > 0) {
      moveGlitch(e.touches[0].clientX, e.touches[0].clientY);
    }
  }, { passive: true });

  box.addEventListener('touchend', stopGlitch, { passive: true });
  box.addEventListener('touchcancel', stopGlitch, { passive: true });

  // Pointer Events (Unified Pointer Down / Pointer Move)
  box.addEventListener('pointerdown', (e) => startGlitch(e.clientX, e.clientY));
  box.addEventListener('pointermove', (e) => {
    if (e.buttons > 0 || targetHover > 0.5) {
      moveGlitch(e.clientX, e.clientY);
    }
  });
  box.addEventListener('pointerup', stopGlitch);
  box.addEventListener('pointercancel', stopGlitch);

  const clock = new threeEngine.Clock();

  function renderLoop() {
    requestAnimationFrame(renderLoop);
    uniforms.uTime.value = clock.getElapsedTime();

    // Responsive & smooth Lerp easing for entering & leaving hover/touch state
    const lerpSpeed = targetHover > uniforms.uHover.value ? 0.16 : 0.10;
    uniforms.uHover.value += (targetHover - uniforms.uHover.value) * lerpSpeed;

    // WebGL Canvas visibility matches hover intensity; static image remains visible
    const hoverVal = uniforms.uHover.value;
    canvas.style.opacity = hoverVal > 0.005 ? hoverVal.toFixed(3) : '0';
    img.style.opacity = '1';

    renderer.render(scene, camera);
  }
  renderLoop();
}

function initHorizontalSliceGlitch() {
  // Hero Portrait Box Glitch Effect ONLY (Disabled for project card images)
  const portraitBox = document.getElementById('portrait-box');
  const portraitCanvas = document.getElementById('portrait-glitch-canvas');
  const portraitImg = document.getElementById('portrait-img');
  if (portraitBox && portraitCanvas && portraitImg) {
    createGlitchEffect(portraitBox, portraitCanvas, portraitImg);
  }
}

/* ============================================
   5. LIVE DIGITAL CLOCK
   ============================================ */
function initClock() {
  const clockEl = document.getElementById('live-clock');
  if (!clockEl) return;

  function tick() {
    const now = new Date();
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    clockEl.textContent = `${hours}:${minutes}:${seconds}`;
  }
  tick();
  setInterval(tick, 1000);
}

/* ============================================
   LETTER COUNTING / MATRIX SCRAMBLE ANIMATION
   Starts with rapidly incrementing counting numbers 0-9 across all slots,
   then locks in character-by-character into targetText.
   ============================================ */
function runCountingLetterAnimation(el, targetText, duration = 1100) {
  if (!el) return;
  const digits = '0123456789';
  const symbols = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ#$@%&';
  const length = targetText.length;
  let startTime = null;

  function step(timestamp) {
    if (!startTime) startTime = timestamp;
    const elapsed = timestamp - startTime;
    const progress = Math.min(elapsed / duration, 1);

    let result = '';
    for (let i = 0; i < length; i++) {
      if (targetText[i] === ' ') {
        result += ' ';
        continue;
      }

      const lockThreshold = 0.2 + (i / length) * 0.8;

      if (progress >= lockThreshold) {
        result += targetText[i];
      } else {
        if (progress < 0.25) {
          result += digits[Math.floor(Math.random() * digits.length)];
        } else {
          result += symbols[Math.floor(Math.random() * symbols.length)];
        }
      }
    }

    el.textContent = result;

    if (progress < 1) {
      requestAnimationFrame(step);
    } else {
      el.textContent = targetText;
    }
  }

  requestAnimationFrame(step);
}
function scrambleText(el, targetText, duration = 850) {
  runCountingLetterAnimation(el, targetText, duration);
}

/* ============================================
   6. SCROLL TRIGGER REVEAL ANIMATIONS (GSAP & IntersectionObserver)
   ============================================ */
function initScrollAnimations() {
  // --- Section Titles Scramble on Scroll (Bidirectional) ---
  const aboutTitle = document.querySelector('.about-title');
  const projectsTitle = document.querySelector('.projects-title');

  const titleObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        if (entry.target === aboutTitle && !aboutTitle.dataset.scrambling) {
          aboutTitle.dataset.scrambling = 'true';
          runCountingLetterAnimation(aboutTitle, 'ABOUT', 850);
          setTimeout(() => { delete aboutTitle.dataset.scrambling; }, 1200);
        } else if (entry.target === projectsTitle && !projectsTitle.dataset.scrambling) {
          projectsTitle.dataset.scrambling = 'true';
          runCountingLetterAnimation(projectsTitle, 'FEATURED WORK', 1100);
          setTimeout(() => { delete projectsTitle.dataset.scrambling; }, 1400);
        }
      }
    });
  }, { threshold: 0.15 });

  if (aboutTitle) titleObserver.observe(aboutTitle);
  if (projectsTitle) titleObserver.observe(projectsTitle);

  // --- General Slide-Up Reveal Observer (Bidirectional: Works scrolling up & down) ---
  const slideObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.classList.add('slide-up');
      } else {
        // Reset when out of view so scrolling back triggers the slide-up reveal again
        entry.target.classList.remove('slide-up');
      }
    });
  }, { threshold: 0.08, rootMargin: '0px 0px -30px 0px' });

  function prepSlide(el, delayMs = 0) {
    if (!el) return;
    el.classList.add('slide-hidden');
    if (delayMs) el.style.transitionDelay = `${delayMs}ms`;
    slideObserver.observe(el);
  }

  // Section titles
  document.querySelectorAll('.about-title, .projects-title').forEach(el => prepSlide(el, 0));

  // About text, quote & skill chips
  document.querySelectorAll('.about-para, .about-quote').forEach((el, i) => prepSlide(el, i * 70));
  document.querySelectorAll('.skill-chip').forEach((el, i) => prepSlide(el, 260 + i * 45));

  // Project Cards
  document.querySelectorAll('.project-card').forEach((card, cardIdx) => {
    prepSlide(card.querySelector('.project-title-mask'), 0);
    prepSlide(card.querySelector('.project-image-wrapper'), 100);
    prepSlide(card.querySelector('.project-desc'), 180);
    card.querySelectorAll('.meta-tag').forEach((tag, tagIdx) => {
      prepSlide(tag, 220 + tagIdx * 45);
    });
  });

  // --- Featured Work File 3D Scroll Reveal Animation ---
  const folderFile = document.getElementById('featured-glass-file');
  const folderCanvas = document.getElementById('featured-ascii-canvas');
  if (folderFile) {
    folderFile.classList.add('file-reveal-init');
    if (folderCanvas) folderCanvas.classList.add('canvas-reveal-init');

    const fileObserver = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          folderFile.classList.add('file-revealed');
          if (folderCanvas) folderCanvas.classList.add('canvas-revealed');
        } else {
          // Reset when scrolled past above or below so scrolling triggers it again smoothly
          const rect = entry.boundingClientRect;
          if (rect.top > window.innerHeight * 0.85 || rect.bottom < 0) {
            folderFile.classList.remove('file-revealed');
            if (folderCanvas) folderCanvas.classList.remove('canvas-revealed');
          }
        }
      });
    }, {
      threshold: 0.12,
      rootMargin: '0px 0px -40px 0px'
    });

    fileObserver.observe(folderFile);

    // Initial check in case user loaded the page scrolled to projects
    const initialRect = folderFile.getBoundingClientRect();
    if (initialRect.top < window.innerHeight - 50 && initialRect.bottom > 50) {
      folderFile.classList.add('file-revealed');
      if (folderCanvas) folderCanvas.classList.add('canvas-revealed');
    }
  }
}


/* ============================================
   7. VIEW PROJECT CURSOR BADGE INTERACTION
   ============================================ */
function initViewProjectCursor() {
  const badge = document.getElementById('view-project-cursor');
  const projectWrappers = document.querySelectorAll('.project-image-wrapper');
  if (!badge || projectWrappers.length === 0) return;

  let mouseX = window.innerWidth / 2;
  let mouseY = window.innerHeight / 2;
  let badgeX = mouseX;
  let badgeY = mouseY;
  let isHovering = false;

  window.addEventListener('mousemove', (e) => {
    mouseX = e.clientX;
    mouseY = e.clientY;
  }, { passive: true });

  window.addEventListener('touchmove', (e) => {
    if (e.touches.length > 0) {
      mouseX = e.touches[0].clientX;
      mouseY = e.touches[0].clientY;
    }
  }, { passive: true });

  // Hide view project badge immediately on scroll away from projects
  window.addEventListener('scroll', () => {
    isHovering = false;
    badge.classList.remove('is-active');
    document.body.classList.remove('is-hovering-project');
  }, { passive: true });

  function renderBadge() {
    badgeX += (mouseX - badgeX) * 0.22;
    badgeY += (mouseY - badgeY) * 0.22;
    badge.style.left = `${badgeX}px`;
    badge.style.top = `${badgeY}px`;
    badge.style.transform = `translate(-50%, -50%) scale(${isHovering ? 1 : 0.5})`;
    requestAnimationFrame(renderBadge);
  }
  renderBadge();

  const projectsScreen = document.getElementById('projects');

  projectWrappers.forEach(wrapper => {
    const parentCard = wrapper.closest('.project-card');

    wrapper.addEventListener('mouseenter', (e) => {
      isHovering = true;
      mouseX = e.clientX;
      mouseY = e.clientY;
      badgeX = mouseX;
      badgeY = mouseY;
      badge.classList.add('is-active');
      document.body.classList.add('is-hovering-project');
      if (parentCard) parentCard.classList.add('is-touching');
      if (projectsScreen) projectsScreen.classList.add('is-touching-image');
    });

    wrapper.addEventListener('mouseleave', () => {
      isHovering = false;
      badge.classList.remove('is-active');
      document.body.classList.remove('is-hovering-project');
      if (parentCard) parentCard.classList.remove('is-touching');
      if (projectsScreen) projectsScreen.classList.remove('is-touching-image');

      // When text reappears after touching VIEW PROJECT, re-trigger counting letter animation
      const projectsTitle = document.querySelector('.projects-title');
      if (projectsTitle) {
        runCountingLetterAnimation(projectsTitle, 'FEATURED WORK', 850);
      }
    });
  });
}


/* ============================================
   8. IDENTITY SECTION — SCROLL-TRIGGERED WHITE BG + SLIDE-UP REVEAL
   White background, Bowlby One SC name in black, slow cinematic slide-up.
   ============================================ */
function initIdentitySection() {
  const wrapper = document.getElementById('identity-wrapper');
  const identitySection = document.getElementById('identity');
  const identityName = document.getElementById('identity-name');
  const identityRole = document.getElementById('identity-role');
  const blackout = document.getElementById('identity-blackout');

  if (!wrapper || !identitySection || !identityName || !identityRole) return;

  // Register ScrollTrigger plugin
  gsapEngine.registerPlugin(ScrollTrigger);

  // Blackout is disabled for white section — ensure it stays hidden
  if (blackout) gsapEngine.set(blackout, { opacity: 0, pointerEvents: 'none' });

  // ── AKSHAY slide-up reveal ──────────────────────────────────────
  // The CSS transition handles the actual animation (1.4s cubic-bezier).
  // GSAP ScrollTrigger simply toggles .is-revealed at the right scroll position.
  ScrollTrigger.create({
    trigger: wrapper,
    start: 'top 60%',         // Fires when wrapper top crosses 60% of viewport
    toggleActions: 'play none none reverse',
    onEnter: () => {
      // Small RAF delay so the class flip lands after the browser paint cycle
      requestAnimationFrame(() => {
        identityName.classList.add('is-revealed');
        // Role follows 180ms later (handled by CSS transition-delay: 0.18s)
        identityRole.classList.add('is-revealed');
      });
    },
    onLeaveBack: () => {
      identityName.classList.remove('is-revealed');
      identityRole.classList.remove('is-revealed');
    },
  });

  // White section: no dark-header inversion needed.
  // The header stays in its default light mode while this section is visible.
}



/* ============================================
   9. DOUBLE TAP CIRCLE CURSOR — IDENTITY SECTION
   Small circle cursor with "DOUBLE TAP" text
   follows mouse with smooth GPU-accelerated LERP
   ============================================ */
function initDoubleTapCursor() {
  const dtCursor = document.getElementById('dt-cursor');
  const identityContent = document.getElementById('identity-content');

  if (!dtCursor || !identityContent) return;

  let mouseX = -100;
  let mouseY = -100;
  let cursorX = -100;
  let cursorY = -100;
  let isOverIdentity = false;
  let rafId = null;

  function renderCursor() {
    const lerpFactor = 0.2;
    cursorX += (mouseX - cursorX) * lerpFactor;
    cursorY += (mouseY - cursorY) * lerpFactor;

    dtCursor.style.transform = `translate3d(${cursorX}px, ${cursorY}px, 0) translate(-50%, -50%)`;

    if (isOverIdentity) {
      rafId = requestAnimationFrame(renderCursor);
    } else {
      rafId = null;
    }
  }

  window.addEventListener('mousemove', (e) => {
    mouseX = e.clientX;
    mouseY = e.clientY;
  }, { passive: true });

  identityContent.addEventListener('mouseenter', (e) => {
    isOverIdentity = true;
    mouseX = e.clientX;
    mouseY = e.clientY;
    cursorX = mouseX;
    cursorY = mouseY;
    dtCursor.classList.add('is-visible');
    if (!rafId) {
      rafId = requestAnimationFrame(renderCursor);
    }
  });

  identityContent.addEventListener('mouseleave', () => {
    isOverIdentity = false;
    dtCursor.classList.remove('is-visible');
  });

  // Touch handling
  identityContent.addEventListener('touchstart', (e) => {
    if (e.touches.length > 0) {
      mouseX = e.touches[0].clientX;
      mouseY = e.touches[0].clientY;
      cursorX = mouseX;
      cursorY = mouseY;
      isOverIdentity = true;
      dtCursor.classList.add('is-visible');
      if (!rafId) {
        rafId = requestAnimationFrame(renderCursor);
      }

      setTimeout(() => {
        dtCursor.classList.remove('is-visible');
        isOverIdentity = false;
      }, 1800);
    }
  }, { passive: true });
}

/* ============================================
   10. FULL SUBPAGE & VIDEO PLAYER — DOUBLE TAP OPEN/CLOSE
   ============================================ */
function initSubPage() {
  const identityContent = document.getElementById('identity-content');
  const overlay = document.getElementById('subpage-overlay');
  const closeBtn = document.getElementById('subpage-close');
  const dtCursor = document.getElementById('dt-cursor');
  const subpageContainer = document.getElementById('subpage-container');
  const videoTrack = document.getElementById('subpage-video-track');

  if (!identityContent || !overlay || !closeBtn) return;

  let isOpen = false;
  let lastTapTime = 0;
  let scrollX = 0;
  let targetScrollX = 0;
  let scrollRafId = null;

  // Wire up all video cards with play/pause
  const allVideoCards = document.querySelectorAll('[data-video-card]');
  allVideoCards.forEach(card => {
    const video = card.querySelector('.video-card-media');
    const playBtn = card.querySelector('.video-play-btn');
    const videoFrame = card.querySelector('.video-frame');

    if (!video || !playBtn) return;

    function toggleVideo(e) {
      if (e) e.stopPropagation();

      // Pause all other videos first
      allVideoCards.forEach(otherCard => {
        if (otherCard !== card) {
          const otherVideo = otherCard.querySelector('.video-card-media');
          if (otherVideo && !otherVideo.paused) {
            otherVideo.pause();
            otherCard.classList.remove('is-playing');
          }
        }
      });

      if (video.paused) {
        // Ensure video sound is active and audible
        video.muted = false;
        video.volume = 1.0;
        video.play().then(() => {
          card.classList.add('is-playing');
        }).catch(err => {
          console.warn('Video audio play note:', err);
          // Fallback if browser requires user click acknowledgement
          video.muted = false;
          video.play().then(() => card.classList.add('is-playing'));
        });
      } else {
        video.pause();
        card.classList.remove('is-playing');
      }
    }

    if (videoFrame) {
      videoFrame.addEventListener('click', toggleVideo);
    }
    playBtn.addEventListener('click', toggleVideo);

    video.addEventListener('ended', () => {
      card.classList.remove('is-playing');
    });
  });

  /* ---------- HORIZONTAL SCROLL-DRIVEN MOVEMENT (Right → Left) ---------- */
  function getMaxScroll() {
    if (!videoTrack || !subpageContainer) return 0;
    const trackWidth = videoTrack.scrollWidth;
    const containerWidth = subpageContainer.clientWidth;
    return Math.max(0, trackWidth - containerWidth);
  }

  function smoothScrollTick() {
    const diff = targetScrollX - scrollX;
    if (Math.abs(diff) < 0.5) {
      scrollX = targetScrollX;
    } else {
      scrollX += diff * 0.12;
    }
    if (videoTrack) {
      videoTrack.style.transform = `translate3d(${-scrollX}px, 0, 0)`;
    }
    if (Math.abs(diff) > 0.5) {
      scrollRafId = requestAnimationFrame(smoothScrollTick);
    } else {
      scrollRafId = null;
    }
  }

  function startSmoothScroll() {
    if (!scrollRafId) {
      scrollRafId = requestAnimationFrame(smoothScrollTick);
    }
  }

  // Mouse wheel on the overlay drives horizontal translation
  if (overlay) {
    overlay.addEventListener('wheel', (e) => {
      if (!isOpen) return;
      e.preventDefault();
      const delta = Math.abs(e.deltaY) > Math.abs(e.deltaX) ? e.deltaY : e.deltaX;
      targetScrollX = Math.max(0, Math.min(getMaxScroll(), targetScrollX + delta * 1.2));
      startSmoothScroll();
    }, { passive: false });
  }

  // Touch drag for mobile
  let touchStartX = 0;
  let touchStartScrollX = 0;

  if (overlay) {
    overlay.addEventListener('touchstart', (e) => {
      if (!isOpen || e.touches.length === 0) return;
      touchStartX = e.touches[0].clientX;
      touchStartScrollX = targetScrollX;
    }, { passive: true });

    overlay.addEventListener('touchmove', (e) => {
      if (!isOpen || e.touches.length === 0) return;
      const dx = touchStartX - e.touches[0].clientX;
      targetScrollX = Math.max(0, Math.min(getMaxScroll(), touchStartScrollX + dx));
      startSmoothScroll();
    }, { passive: true });
  }

  /* ---------- ULTRA-SMOOTH 60FPS 3D PARTICLE VORTEX TEXT DISINTEGRATION ---------- */
  const disCanvas = document.getElementById('disintegration-canvas');
  let disRafId = null;
  let isDisintegrating = false;

  function runTextDisintegration(callback) {
    if (!disCanvas || !identityContent || isDisintegrating) {
      if (callback) callback();
      return;
    }

    isDisintegrating = true;
    if (dtCursor) dtCursor.classList.remove('is-visible');

    const dpr = Math.min(window.devicePixelRatio || 1, 1.5);
    const width = window.innerWidth;
    const height = window.innerHeight;

    disCanvas.width = width * dpr;
    disCanvas.height = height * dpr;
    disCanvas.style.width = `${width}px`;
    disCanvas.style.height = `${height}px`;
    disCanvas.style.display = 'block';

    const ctx = disCanvas.getContext('2d', { alpha: true });
    ctx.scale(dpr, dpr);

    // Offscreen high-res canvas for typography sampling
    const offCanvas = document.createElement('canvas');
    offCanvas.width = width;
    offCanvas.height = height;
    const offCtx = offCanvas.getContext('2d');

    const nameEl = document.getElementById('identity-name');
    const roleEl = document.getElementById('identity-role');

    const nameRect = nameEl ? nameEl.getBoundingClientRect() : null;
    const roleRect = roleEl ? roleEl.getBoundingClientRect() : null;

    const nameStyle = nameEl ? window.getComputedStyle(nameEl) : null;
    const roleStyle = roleEl ? window.getComputedStyle(roleEl) : null;

    let centerX = width / 2;
    let centerY = height / 2;

    offCtx.textAlign = 'center';
    offCtx.textBaseline = 'middle';

    // 1. Render AKSHAY in Dark Smooth Red
    if (nameEl && nameRect && nameStyle) {
      const nx = nameRect.left + nameRect.width / 2;
      const ny = nameRect.top + nameRect.height / 2;
      centerX = nx;
      centerY = ny;
      
      const fontSizePx = Math.round(parseFloat(nameStyle.fontSize)) || 160;
      offCtx.font = `normal ${fontSizePx}px 'Varien', sans-serif`;
      offCtx.fillStyle = '#780E24';
      offCtx.fillText(nameEl.textContent.trim() || 'AKSHAY', nx, ny);
    }

    // 2. Render Freelancer in Crisp White
    if (roleEl && roleRect && roleStyle) {
      const rx = roleRect.left + roleRect.width / 2;
      const ry = roleRect.top + roleRect.height / 2;
      
      const roleFontSizePx = Math.round(parseFloat(roleStyle.fontSize)) || 22;
      offCtx.font = `500 ${roleFontSizePx}px 'Inter', sans-serif`;
      offCtx.fillStyle = '#ffffff';
      offCtx.fillText(roleEl.textContent.trim() || 'Freelancer', rx, ry);
    }

    const imgData = offCtx.getImageData(0, 0, width, height);
    const data = imgData.data;

    // Refined, elegant particle density (step = 5.0 gives ~1,200 delicate particles instead of overwhelming noise)
    const step = 5.0;
    let count = 0;
    for (let y = 0; y < height; y += step) {
      const rowIdx = Math.floor(y) * width;
      for (let x = 0; x < width; x += step) {
        const idx = (rowIdx + Math.floor(x)) * 4;
        if (data[idx + 3] > 40) count++;
      }
    }

    // Allocate flat TypedArrays in contiguous memory
    const pOriginX = new Float32Array(count);
    const pOriginY = new Float32Array(count);
    const pRadius = new Float32Array(count);
    const pAngle = new Float32Array(count);
    const pDistOffset = new Float32Array(count);
    const pSwirlSpeed = new Float32Array(count);
    const pSpinDir = new Float32Array(count);
    const pSize = new Float32Array(count);
    const pFadeStart = new Float32Array(count);

    let pIdx = 0;
    for (let y = 0; y < height; y += step) {
      const rowIdx = Math.floor(y) * width;
      for (let x = 0; x < width; x += step) {
        const idx = (rowIdx + Math.floor(x)) * 4;
        const alpha = data[idx + 3];
        if (alpha > 40 && pIdx < count) {
          const px = x + (Math.random() - 0.5) * 1.2;
          const py = y + (Math.random() - 0.5) * 1.2;
          const dx = px - centerX;
          const dy = py - centerY;

          pOriginX[pIdx] = px;
          pOriginY[pIdx] = py;
          pRadius[pIdx] = Math.hypot(dx, dy);
          pAngle[pIdx] = Math.atan2(dy, dx);
          pDistOffset[pIdx] = dx * 0.004 + dy * 0.003;
          pSwirlSpeed[pIdx] = 0.85 + Math.random() * 0.4;
          pSpinDir[pIdx] = (Math.random() > 0.48 ? 1 : -1) * (1.0 + Math.random() * 0.25);
          pSize[pIdx] = 1.8 + Math.random() * 1.4; // Delicate, refined particle sizes
          pFadeStart[pIdx] = 0.45 + Math.random() * 0.45;
          pIdx++;
        }
      }
    }

    // Seamless handover: Hide original DOM text immediately
    identityContent.classList.add('is-disintegrating');

    const DURATION = 2000; // Exact 2.0s
    const startTime = performance.now();

    function animate(now) {
      const elapsed = now - startTime;
      const progress = Math.min(1, elapsed / DURATION);

      // Smooth silky motion trail over pitch black
      ctx.fillStyle = 'rgba(0, 0, 0, 0.35)';
      ctx.fillRect(0, 0, width, height);

      // Pre-calculate frame-wide animation terms
      const easeProgress = 1 - Math.pow(1 - progress, 2.4);
      const waveAmp = Math.sin(progress * Math.PI * 1.1) * Math.max(0, 1 - progress * 1.3) * 18;
      const swirlPower = Math.pow(easeProgress, 1.8);
      const pinchFactor = Math.sin(easeProgress * Math.PI) * 0.38;
      const sizeProgressDecay = Math.max(0.3, 1 - progress * 0.55);

      for (let i = 0; i < count; i++) {
        // 1. Subtle 3D Wave displacement
        const waveX = Math.sin(pOriginY[i] * 0.015 - progress * 12 + pDistOffset[i]) * waveAmp;
        const waveY = Math.cos(pOriginX[i] * 0.012 - progress * 10) * (waveAmp * 0.7);

        // 2. Swirling Vortex Angle
        const curAngle = pAngle[i] + (pSpinDir[i] * swirlPower * 5.8 * pSwirlSpeed[i]);

        // 3. Focused elegant vortex pinch & gentle drift
        const pinch = 1 - pinchFactor * Math.cos(curAngle * 2);
        const curRadius = pRadius[i] * (1 + swirlPower * 1.15 * pSwirlSpeed[i]) * pinch;

        // 4. Position calculation
        const curX = centerX + Math.cos(curAngle) * curRadius + waveX;
        const curY = centerY + Math.sin(curAngle) * curRadius * 0.88 + waveY;

        // 5. Soft translucent alpha dissolve
        let curAlpha = 0.65; // Softer, subtler, ethereal stardust glow
        const fStart = pFadeStart[i];
        if (progress > fStart) {
          const fadeP = (progress - fStart) / (1.0 - fStart);
          curAlpha = Math.max(0, 0.65 * (1 - Math.pow(fadeP, 1.6)));
        }

        const curSize = pSize[i] * sizeProgressDecay;

        if (curAlpha > 0.02) {
          // Soft, delicate white stardust
          ctx.fillStyle = `rgba(255, 255, 255, ${curAlpha})`;
          ctx.fillRect(curX - curSize * 0.5, curY - curSize * 0.5, curSize, curSize);
        }
      }

      if (progress < 1) {
        disRafId = requestAnimationFrame(animate);
      } else {
        ctx.clearRect(0, 0, width, height);
        disCanvas.style.display = 'none';
        isDisintegrating = false;
        if (callback) callback();
      }
    }

    disRafId = requestAnimationFrame(animate);
  }

  /* ---------- SUBPAGE 2-SECOND FONT MORPHING LOADER (AR MONOGRAM) ---------- */
  const loaderEl = document.getElementById('subpage-loader');
  const morphTextEl = document.getElementById('morph-ar-text');
  const morphProgressFillEl = document.getElementById('morph-progress-fill');
  const morphProgressNumEl = document.getElementById('morph-progress-num');

  const MORPH_FONTS = [
    { name: 'Mexican fiesta', family: "'Mexican fiesta', fantasy, cursive, sans-serif" },
    { name: 'Excess V', family: "'Excess V', 'Excess V Straight', sans-serif" },
    { name: 'Minercraftory', family: "'Minercraftory', sans-serif" },
    { name: 'Blackout', family: "'Blackout', Impact, sans-serif" },
    { name: 'Inversionz', family: "'Inversionz', monospace, sans-serif" }
  ];

  let loaderAnimId = null;

  function runSubPageLoader(callback) {
    if (!loaderEl || !morphTextEl) {
      if (callback) callback();
      return;
    }

    if (loaderAnimId) {
      cancelAnimationFrame(loaderAnimId);
      loaderAnimId = null;
    }

    // Reset loader elements
    overlay.classList.remove('is-loaded');
    loaderEl.classList.remove('is-exiting');
    loaderEl.classList.add('is-active');

    if (morphProgressFillEl) morphProgressFillEl.style.width = '0%';
    if (morphProgressNumEl) morphProgressNumEl.textContent = '0%';

    const DURATION = 2000; // 2 seconds exact
    const startTime = performance.now();
    let currentFontIdx = -1;
    let lastFontSwitchTime = 0;
    const FONT_INTERVAL = 110; // Switch font every 110ms

    function frame(now) {
      const elapsed = now - startTime;
      const progress = Math.min(1, elapsed / DURATION);

      // Smooth progress update
      const pct = Math.floor(progress * 100);
      if (morphProgressFillEl) morphProgressFillEl.style.width = `${pct}%`;
      if (morphProgressNumEl) morphProgressNumEl.textContent = `${pct}%`;

      // Cycle font every FONT_INTERVAL ms
      if (now - lastFontSwitchTime >= FONT_INTERVAL && progress < 1) {
        lastFontSwitchTime = now;
        currentFontIdx = (currentFontIdx + 1) % MORPH_FONTS.length;
        const fontObj = MORPH_FONTS[currentFontIdx];

        if (morphTextEl) {
          morphTextEl.style.fontFamily = fontObj.family;
          morphTextEl.classList.remove('is-pulsing');
          void morphTextEl.offsetWidth; // trigger reflow
          morphTextEl.classList.add('is-pulsing');
        }
      }

      if (progress < 1) {
        loaderAnimId = requestAnimationFrame(frame);
      } else {
        // Complete 2s loading
        if (morphProgressFillEl) morphProgressFillEl.style.width = '100%';
        if (morphProgressNumEl) morphProgressNumEl.textContent = '100%';

        setTimeout(() => {
          // Exit loader animation
          loaderEl.classList.add('is-exiting');
          overlay.classList.add('is-loaded');

          setTimeout(() => {
            loaderEl.classList.remove('is-active', 'is-exiting');
            if (callback) callback();
          }, 450);
        }, 80);
      }
    }

    loaderAnimId = requestAnimationFrame(frame);
  }

  function initVideoThumbnails() {
    const allVideos = document.querySelectorAll('.video-card-media');
    allVideos.forEach(video => {
      video.muted = true;
      video.playsInline = true;

      const renderThumbnail = () => {
        if (video.currentTime === 0 && !video.dataset.thumbSet) {
          try {
            video.currentTime = 0.5;
            video.dataset.thumbSet = 'true';
          } catch (e) {
            // Ignore if video cannot seek yet
          }
        }
      };

      video.addEventListener('loadedmetadata', renderThumbnail);
      video.addEventListener('loadeddata', renderThumbnail);
      video.addEventListener('canplay', renderThumbnail);

      if (video.readyState >= 1) {
        renderThumbnail();
      }
    });
  }

  function openSubPage() {
    if (isOpen) return;
    isOpen = true;
    // Reset scroll position
    scrollX = 0;
    targetScrollX = 0;
    if (videoTrack) videoTrack.style.transform = 'translate3d(0, 0, 0)';
    if (dtCursor) dtCursor.classList.remove('is-visible');
    overlay.classList.add('is-open');
    document.body.classList.add('is-subpage-open');
    initVideoThumbnails();

    // Start 2-second font morphing loading sequence
    runSubPageLoader(() => {
      // Subpage video cards now fully revealed
    });
  }

  function closeSubPage() {
    if (!isOpen && !isDisintegrating) return;
    isOpen = false;
    isDisintegrating = false;
    if (disRafId) {
      cancelAnimationFrame(disRafId);
      disRafId = null;
    }
    if (disCanvas) {
      const ctx = disCanvas.getContext('2d');
      ctx.clearRect(0, 0, disCanvas.width, disCanvas.height);
      disCanvas.style.display = 'none';
    }
    if (identityContent) {
      identityContent.classList.remove('is-disintegrating');
    }
    if (loaderAnimId) {
      cancelAnimationFrame(loaderAnimId);
      loaderAnimId = null;
    }
    // Pause all playing videos on close
    allVideoCards.forEach(card => {
      const video = card.querySelector('.video-card-media');
      if (video && !video.paused) {
        video.pause();
        card.classList.remove('is-playing');
      }
    });
    overlay.classList.remove('is-open', 'is-loaded');
    if (loaderEl) loaderEl.classList.remove('is-active', 'is-exiting');
    document.body.classList.remove('is-subpage-open');
  }

  function triggerSubPageEntry() {
    if (isOpen || isDisintegrating) return;
    runTextDisintegration(() => {
      openSubPage();
    });
  }

  // Desktop double-click
  identityContent.addEventListener('dblclick', (e) => {
    e.preventDefault();
    triggerSubPageEntry();
  });

  // Mobile double-tap (within 350ms)
  identityContent.addEventListener('touchend', (e) => {
    const now = Date.now();
    if (now - lastTapTime < 350) {
      e.preventDefault();
      triggerSubPageEntry();
      lastTapTime = 0;
    } else {
      lastTapTime = now;
    }
  });

  // Close button
  closeBtn.addEventListener('click', closeSubPage);

  // Close on Escape key
  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && (isOpen || isDisintegrating)) {
      closeSubPage();
    }
  });

  initVideoThumbnails();
}

/* ============================================
   LIQUID GLASS IOS 3D COVERFLOW ENGINE
   ============================================ */
function initLiquidGlassCoverflow() {
  const stage = document.getElementById('certs-coverflow-stage');
  const arcContainer = document.getElementById('certs-cards-arc');
  const cards = Array.from(document.querySelectorAll('.liquid-cert-card'));
  const dots = Array.from(document.querySelectorAll('.cert-dot'));
  const prevBtn = document.getElementById('certs-prev-btn');
  const nextBtn = document.getElementById('certs-next-btn');

  if (!stage || !arcContainer || cards.length === 0) return;

  let activeIndex = 0;
  const total = cards.length;

  function updateCoverflow(newIndex) {
    activeIndex = (newIndex + total) % total;
    const isMobile = window.innerWidth < 768;

    cards.forEach((card, idx) => {
      let offset = idx - activeIndex;
      if (offset > total / 2) offset -= total;
      if (offset < -total / 2) offset += total;

      const absOffset = Math.abs(offset);
      const sign = Math.sign(offset);

      let tx = 0;
      let ty = 0;
      let tz = 0;
      let rotY = 0;
      let rotZ = 0;
      let scale = 1;
      let zIndex = 10;
      let opacity = 1;
      let filter = 'none';

      if (offset === 0) {
        // Active Center Card: pops to the front with elevation and unfolds
        tx = 0;
        ty = isMobile ? 5 : 12;
        tz = isMobile ? 80 : 130;
        rotY = 0;
        rotZ = 0;
        scale = isMobile ? 1.02 : 1.05;
        zIndex = 50;
        opacity = 1;
        filter = 'brightness(1)';
        card.classList.add('is-active');
      } else if (absOffset === 1) {
        // Immediate Neighbors (Left & Right)
        const stepX = isMobile ? 110 : 230;
        tx = sign * stepX;
        ty = isMobile ? 22 : 36;
        tz = isMobile ? 10 : 20;
        rotY = -sign * (isMobile ? 18 : 24);
        rotZ = sign * (isMobile ? 4 : 6);
        scale = isMobile ? 0.86 : 0.88;
        zIndex = 35;
        opacity = 0.95;
        filter = 'brightness(0.96)';
        card.classList.remove('is-active');
      } else {
        // Outer Cards (Offset 2)
        const stepX = isMobile ? 190 : 420;
        tx = sign * stepX;
        ty = isMobile ? 38 : 60;
        tz = isMobile ? -30 : -60;
        rotY = -sign * (isMobile ? 28 : 36);
        rotZ = sign * (isMobile ? 8 : 12);
        scale = isMobile ? 0.74 : 0.76;
        zIndex = 20;
        opacity = 0.88;
        filter = 'brightness(0.92)';
        card.classList.remove('is-active');
      }

      card.style.transform = `translate3d(calc(-50% + ${tx}px), calc(-50% + ${ty}px), ${tz}px) rotateY(${rotY}deg) rotateZ(${rotZ}deg) scale(${scale})`;
      card.style.zIndex = zIndex;
      card.style.opacity = opacity;
      card.style.filter = filter;
    });

    if (window.lucide && typeof window.lucide.createIcons === 'function') {
      window.lucide.createIcons();
    }

    // Update Dots
    dots.forEach((dot, dIdx) => {
      dot.classList.toggle('is-active', dIdx === activeIndex);
    });
  }

  // Touch / Click on card brings it forward
  cards.forEach((card, idx) => {
    card.addEventListener('click', (e) => {
      e.stopPropagation();
      updateCoverflow(idx);
    });

    card.addEventListener('touchstart', (e) => {
      updateCoverflow(idx);
    }, { passive: true });
  });

  // Dots click
  dots.forEach((dot, dIdx) => {
    dot.addEventListener('click', () => {
      updateCoverflow(dIdx);
    });
  });

  // Prev / Next buttons
  if (prevBtn) {
    prevBtn.addEventListener('click', () => {
      updateCoverflow(activeIndex - 1);
    });
  }
  if (nextBtn) {
    nextBtn.addEventListener('click', () => {
      updateCoverflow(activeIndex + 1);
    });
  }

  // Touch swipe support on coverflow stage
  let touchStartX = 0;
  let touchEndX = 0;

  arcContainer.addEventListener('touchstart', (e) => {
    if (e.touches.length > 0) {
      touchStartX = e.touches[0].clientX;
    }
  }, { passive: true });

  arcContainer.addEventListener('touchend', (e) => {
    if (e.changedTouches.length > 0) {
      touchEndX = e.changedTouches[0].clientX;
      const diff = touchEndX - touchStartX;
      if (Math.abs(diff) > 40) {
        if (diff < 0) {
          updateCoverflow(activeIndex + 1);
        } else {
          updateCoverflow(activeIndex - 1);
        }
      }
    }
  }, { passive: true });

  // Initial layout
  updateCoverflow(0);

  // Resize listener for responsive 3D recalculation
  window.addEventListener('resize', () => {
    updateCoverflow(activeIndex);
  });
}

/* ============================================
   LIQUID GLASS IOS CERTIFICATE PDF MODAL ENGINE
   ============================================ */
function initCertificatePdfViewer() {
  const modal = document.getElementById('cert-pdf-modal');
  const frame = document.getElementById('cert-pdf-frame');
  const modalTitle = document.getElementById('cert-pdf-modal-title');
  const externalLink = document.getElementById('cert-pdf-external-link');
  const closeBtn = document.getElementById('cert-pdf-close-btn');
  const pdfTriggers = document.querySelectorAll('.cert-view-pdf-btn, .glass-file-icon-badge');

  if (!modal || !frame) return;

  function openPdfModal(pdfUrl, title) {
    if (!pdfUrl) return;
    frame.src = pdfUrl;
    if (modalTitle) modalTitle.textContent = title || 'Certificate Preview';
    if (externalLink) externalLink.href = pdfUrl;

    modal.classList.add('is-open');
    modal.setAttribute('aria-hidden', 'false');
    document.body.style.overflow = 'hidden';
  }

  function closePdfModal() {
    modal.classList.remove('is-open');
    modal.setAttribute('aria-hidden', 'true');
    document.body.style.overflow = '';
    setTimeout(() => {
      if (!modal.classList.contains('is-open')) {
        frame.src = 'about:blank';
      }
    }, 400);
  }

  pdfTriggers.forEach(btn => {
    btn.addEventListener('click', (e) => {
      e.stopPropagation();
      e.preventDefault();
      const pdfUrl = btn.getAttribute('data-pdf') || btn.closest('.liquid-cert-card')?.getAttribute('data-pdf');
      const title = btn.getAttribute('data-title') || btn.closest('.liquid-cert-card')?.getAttribute('data-title');
      openPdfModal(pdfUrl, title);
    });

    btn.addEventListener('touchend', (e) => {
      e.stopPropagation();
      const pdfUrl = btn.getAttribute('data-pdf') || btn.closest('.liquid-cert-card')?.getAttribute('data-pdf');
      const title = btn.getAttribute('data-title') || btn.closest('.liquid-cert-card')?.getAttribute('data-title');
      openPdfModal(pdfUrl, title);
    });
  });

  if (closeBtn) {
    closeBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      closePdfModal();
    });
  }

  modal.addEventListener('click', (e) => {
    if (e.target === modal) {
      closePdfModal();
    }
  });

  window.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && modal.classList.contains('is-open')) {
      closePdfModal();
    }
  });
}

/* ============================================
   ABOUT SECTION: DRAGGABLE 3D HOLOGRAPHIC STAR
   Supports continuous 360-degree rotation in loop mode
   with fluid drag-and-drop across the About section.
   ============================================ */
function initAboutDraggableObject() {
  const wrapper = document.getElementById('about-draggable-object');
  const container = document.getElementById('about');
  if (!wrapper || !container) return;

  // Clean star image background to true transparent PNG
  const starImg = document.getElementById('about-star-img');
  if (starImg) {
    const rawImg = new Image();
    rawImg.crossOrigin = 'anonymous';
    rawImg.src = starImg.src;
    rawImg.onload = () => {
      try {
        const c = document.createElement('canvas');
        c.width = rawImg.naturalWidth || rawImg.width;
        c.height = rawImg.naturalHeight || rawImg.height;
        const ctx = c.getContext('2d');
        ctx.drawImage(rawImg, 0, 0);
        const imgData = ctx.getImageData(0, 0, c.width, c.height);
        const d = imgData.data;
        for (let i = 0; i < d.length; i += 4) {
          const r = d[i], g = d[i+1], b = d[i+2];
          const brightness = (r * 0.299 + g * 0.587 + b * 0.114);
          if (brightness > 240) {
            d[i+3] = 0;
          } else if (brightness > 220) {
            d[i+3] = Math.floor(((240 - brightness) / 20) * 255);
          }
        }
        ctx.putImageData(imgData, 0, 0);
        starImg.src = c.toDataURL('image/png');
      } catch (_) {}
    };
  }

  // --- Fluid Drag Handling in Background ---
  let isDragging = false;
  let startX = 0, startY = 0;
  let initialLeft = 0, initialTop = 0;

  function onPointerDown(e) {
    if (e.button !== undefined && e.button !== 0) return;
    isDragging = true;
    wrapper.classList.add('is-dragging');

    const rect = wrapper.getBoundingClientRect();
    const containerRect = container.getBoundingClientRect();

    const curLeft = rect.left - containerRect.left;
    const curTop = rect.top - containerRect.top;

    wrapper.style.right = 'auto';
    wrapper.style.bottom = 'auto';
    wrapper.style.transform = 'none';
    wrapper.style.left = `${curLeft}px`;
    wrapper.style.top = `${curTop}px`;

    initialLeft = curLeft;
    initialTop = curTop;
    startX = e.clientX || 0;
    startY = e.clientY || 0;

    if (wrapper.setPointerCapture) {
      try { wrapper.setPointerCapture(e.pointerId); } catch (_) {}
    }

    window.addEventListener('pointermove', onPointerMove, { passive: false });
    window.addEventListener('pointerup', onPointerUp);
    window.addEventListener('pointercancel', onPointerUp);
  }

  function onPointerMove(e) {
    if (!isDragging) return;
    e.preventDefault();

    const clientX = e.clientX || 0;
    const clientY = e.clientY || 0;

    const dx = clientX - startX;
    const dy = clientY - startY;

    let newLeft = initialLeft + dx;
    let newTop = initialTop + dy;

    const containerWidth = container.offsetWidth;
    const containerHeight = container.offsetHeight;
    const elWidth = wrapper.offsetWidth;
    const elHeight = wrapper.offsetHeight;

    newLeft = Math.max(-elWidth * 0.2, Math.min(containerWidth - elWidth * 0.8, newLeft));
    newTop = Math.max(-elHeight * 0.1, Math.min(containerHeight - elHeight * 0.9, newTop));

    wrapper.style.left = `${newLeft}px`;
    wrapper.style.top = `${newTop}px`;
  }

  function onPointerUp(e) {
    if (!isDragging) return;
    isDragging = false;
    wrapper.classList.remove('is-dragging');

    if (e && wrapper.releasePointerCapture) {
      try { wrapper.releasePointerCapture(e.pointerId); } catch (_) {}
    }

    window.removeEventListener('pointermove', onPointerMove);
    window.removeEventListener('pointerup', onPointerUp);
    window.removeEventListener('pointercancel', onPointerUp);
  }

  wrapper.addEventListener('pointerdown', onPointerDown);
}

/* ============================================
   DEDICATED FEATURED WORK / PROJECTS SUB-PAGE CONTROLLER & STICKY STACKING CARDS ENGINE
   ============================================ */
function initFeaturedProjectsSubpage() {
  const overlay = document.getElementById('projects-subpage-overlay');
  const closeBtn = document.getElementById('projects-subpage-close');
  const backdrop = document.getElementById('projects-subpage-backdrop');
  const glassFile = document.getElementById('featured-glass-file');
  const scrollWrap = document.getElementById('projects-subpage-scroll');

  if (!overlay || !closeBtn || !glassFile) return;

  let isOpen = false;

  function updateHeadingMetrics() {
    const heading1 = document.querySelector('.project-name-scroll-card');
    if (heading1) {
      const h1Height = heading1.offsetHeight;
      if (h1Height > 0) {
        document.documentElement.style.setProperty('--heading1-height', `${h1Height}px`);
      }
    }
  }

  function openProjectsSubpage() {
    if (isOpen) return;
    isOpen = true;
    overlay.classList.add('is-open');
    document.body.classList.add('is-projects-subpage-open');
    if (scrollWrap) {
      scrollWrap.scrollTop = 0;
    }
    updateHeadingMetrics();
    if (window.lucide && typeof window.lucide.createIcons === 'function') {
      window.lucide.createIcons();
    }
    // Refresh stacking calculations & smooth text blur reveals
    requestAnimationFrame(() => {
      handleStickyStacking();
      updateSubpageTextBlur();
    });
    setTimeout(updateSubpageTextBlur, 120);
    setTimeout(updateSubpageTextBlur, 350);
  }

  window.addEventListener('resize', updateHeadingMetrics);

  function closeProjectsSubpage() {
    if (!isOpen) return;
    isOpen = false;
    overlay.classList.remove('is-open');
    document.body.classList.remove('is-projects-subpage-open');
  }

  // Open triggers on the glass folder
  glassFile.addEventListener('click', (e) => {
    e.preventDefault();
    openProjectsSubpage();
  });

  glassFile.addEventListener('touchend', (e) => {
    e.preventDefault();
    openProjectsSubpage();
  });

  glassFile.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      openProjectsSubpage();
    }
  });

  // Close triggers
  closeBtn.addEventListener('click', closeProjectsSubpage);
  if (backdrop) backdrop.addEventListener('click', closeProjectsSubpage);

  document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape' && isOpen) {
      closeProjectsSubpage();
    }
  });

  if (window.location.hash === '#featured' || new URLSearchParams(window.location.search).has('featured')) {
    setTimeout(openProjectsSubpage, 200);
  }

  /* ============================================
     STICKY STACKING CARDS REVEAL EFFECT & 3D DEPTH CARD OVERLAP (120FPS RAF)
     ============================================ */
  const cards = document.querySelectorAll('.projects-stack-card');
  let stackingRafId = null;

  function handleStickyStacking() {
    if (!scrollWrap || cards.length < 2) return;

    const wrapRect = scrollWrap.getBoundingClientRect();
    const vh = scrollWrap.clientHeight || window.innerHeight;

    // Iterate over each pair of adjacent cards: apply depth effect to card[i] when card[i+1] approaches
    for (let i = 0; i < cards.length - 1; i++) {
      const currentCard = cards[i];
      const nextCard = cards[i + 1];
      if (!currentCard || !nextCard) continue;

      const nextCardRect = nextCard.getBoundingClientRect();
      const distToHeader = nextCardRect.top - wrapRect.top - 64;

      if (distToHeader < vh && distToHeader > 0) {
        const progress = 1 - (distToHeader / vh);
        const scale = 1 - (progress * 0.04);
        const translateY = -progress * 20;
        const brightness = 1 - (progress * 0.2);

        currentCard.style.transform = `scale(${scale.toFixed(4)}) translateY(${translateY.toFixed(2)}px)`;
        currentCard.style.filter = `brightness(${brightness.toFixed(3)})`;
      } else if (distToHeader <= 0) {
        currentCard.style.transform = 'scale(0.96) translateY(-20px)';
        currentCard.style.filter = 'brightness(0.8)';
      } else {
        if (currentCard.style.transform) currentCard.style.transform = '';
        if (currentCard.style.filter) currentCard.style.filter = '';
      }
    }
  }

  /* ============================================
     FEATURED WORK SUBPAGE: LUXURY TEXT BLUR REVEAL ON SCROLL
     ============================================ */
  const blurTargetSelectors = [
    // --- CARD 01: AI RESUME ENHANCER & ANALYSER ---
    '#project-card-resume .project-card-mini-badge',
    '#project-card-resume .project-card-main-title',
    '#project-card-resume .project-card-subhead',
    '#project-card-resume .resume-badge-eyebrow',
    '#project-card-resume .resume-hero-title',
    '#project-card-resume .resume-hero-desc',
    '#project-card-resume .resume-promo-brand',
    '#project-card-resume .resume-promo-title',
    '#project-card-resume .resume-promo-text',
    '#project-card-resume .tag-pill',
    '#project-card-resume .resume-auth-title',
    '#project-card-resume .resume-auth-subtitle',
    '#project-card-resume .demo-box-title',
    '#project-card-resume .demo-box-text',
    '#project-card-resume .section-eyebrow',
    '#project-card-resume .section-display-heading',
    '#project-card-resume .story-lead-text',
    '#project-card-resume .section-subtext',
    '#project-card-resume .principle-title',
    '#project-card-resume .principle-desc',
    '#project-card-resume .dash-brand-label',
    '#project-card-resume .dash-welcome-text',
    '#project-card-resume .dash-user-label',
    '#project-card-resume .dash-card-title',
    '#project-card-resume .dash-card-subtitle',
    '#project-card-resume .dash-card-text',
    '#project-card-resume .aside-card-title',
    '#project-card-resume .benchmark-info',
    '#project-card-resume .status-card-title',
    '#project-card-resume .status-card-text',
    '#project-card-resume .activity-brand-tag',
    '#project-card-resume .activity-user-tag',
    '#project-card-resume .activity-list-title',
    '#project-card-resume .activity-row-title',
    '#project-card-resume .activity-row-desc',
    '#project-card-resume .tips-card-title',
    '#project-card-resume .tip-item',
    '#project-card-resume .activity-desc-paragraph',
    '#project-card-resume .check-text',
    '#project-card-resume .cta-eyebrow',
    '#project-card-resume .cta-heading',
    '#project-card-resume .cta-desc',
    '#project-card-resume .footer-title',
    '#project-card-resume .footer-copy',

    // --- CARD 02: DESIGNFORGE ---
    '#project-card-designforge .df-card-mini-badge',
    '#project-card-designforge .df-card-main-title',
    '#project-card-designforge .df-card-subhead',
    '#project-card-designforge .df-badge-eyebrow',
    '#project-card-designforge .df-hero-title',
    '#project-card-designforge .df-hero-desc',
    '#project-card-designforge .df-section-eyebrow',
    '#project-card-designforge .df-section-heading',
    '#project-card-designforge .df-story-desc',
    '#project-card-designforge .df-dash-card-title',
    '#project-card-designforge .df-dash-card-text',
    '#project-card-designforge .df-tool-title',
    '#project-card-designforge .df-tool-desc',
    '#project-card-designforge .df-cta-eyebrow',
    '#project-card-designforge .df-cta-heading',
    '#project-card-designforge .df-cta-desc',
    '#project-card-designforge .df-footer-title',
    '#project-card-designforge .df-footer-copy',

    // --- CARD 03: AI POWERED PROMO KIT ---
    '#project-card-promokit .pk-card-mini-badge',
    '#project-card-promokit .pk-card-main-title',
    '#project-card-promokit .pk-card-subhead',
    '#project-card-promokit .pk-badge-eyebrow',
    '#project-card-promokit .pk-hero-title',
    '#project-card-promokit .pk-hero-desc',
    '#project-card-promokit .pk-section-eyebrow',
    '#project-card-promokit .pk-section-heading',
    '#project-card-promokit .pk-telemetry-desc',
    '#project-card-promokit .pk-dash-card-title',
    '#project-card-promokit .pk-dash-card-text',
    '#project-card-promokit .pk-tool-title',
    '#project-card-promokit .pk-tool-desc',
    '#project-card-promokit .pk-activity-title',
    '#project-card-promokit .pk-activity-row-title',
    '#project-card-promokit .pk-activity-row-desc',
    '#project-card-promokit .pk-cta-eyebrow',
    '#project-card-promokit .pk-cta-heading',
    '#project-card-promokit .pk-cta-desc',
    '#project-card-promokit .pk-footer-title',
    '#project-card-promokit .pk-footer-copy'
  ];

  const subpageTextNodes = scrollWrap ? scrollWrap.querySelectorAll(blurTargetSelectors.join(', ')) : [];

  subpageTextNodes.forEach((el) => {
    el.classList.add('subpage-text-blur');
    const tag = el.tagName.toLowerCase();
    const cls = el.className;
    if (cls.includes('eyebrow') || cls.includes('mini-badge') || cls.includes('brand-tag') || cls.includes('tag-pill')) {
      el.setAttribute('data-blur-delay', '1');
    } else if (tag === 'h1' || cls.includes('main-title') || cls.includes('hero-title')) {
      el.setAttribute('data-blur-delay', '2');
    } else if (tag === 'h2' || cls.includes('heading') || cls.includes('section-display-heading')) {
      el.setAttribute('data-blur-delay', '2');
    } else if (tag === 'h3' || cls.includes('title') || cls.includes('card-title')) {
      el.setAttribute('data-blur-delay', '3');
    } else if (tag === 'p' || cls.includes('desc') || cls.includes('subhead') || cls.includes('lead') || cls.includes('text') || cls.includes('subtitle')) {
      el.setAttribute('data-blur-delay', '3');
    } else if (cls.includes('check-text') || cls.includes('tip-item') || cls.includes('row-desc')) {
      el.setAttribute('data-blur-delay', '4');
    } else {
      el.setAttribute('data-blur-delay', '2');
    }
  });

  function updateSubpageTextBlur() {
    if (!scrollWrap || subpageTextNodes.length === 0) return;
    const wrapRect = scrollWrap.getBoundingClientRect();
    const wrapTop = wrapRect.top;
    const wrapBottom = wrapRect.bottom;

    subpageTextNodes.forEach((el) => {
      const rect = el.getBoundingClientRect();
      // Element is entering/visible within the scroll container
      const inView = rect.top < (wrapBottom - 25) && rect.bottom > (wrapTop + 10);
      if (inView) {
        el.classList.add('is-revealed');
      } else if (rect.top > wrapBottom) {
        // Reset when scrolled below so scrolling down triggers blur reveal smoothly
        el.classList.remove('is-revealed');
      }
    });
  }

  // IntersectionObserver for native off-thread performance
  if (scrollWrap && typeof IntersectionObserver !== 'undefined') {
    const subpageTextObserver = new IntersectionObserver((entries) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-revealed');
        } else {
          const wrapRect = scrollWrap.getBoundingClientRect();
          const rect = entry.target.getBoundingClientRect();
          if (rect.top > wrapRect.bottom) {
            entry.target.classList.remove('is-revealed');
          }
        }
      });
    }, {
      root: scrollWrap,
      threshold: 0.08,
      rootMargin: '0px 0px -20px 0px'
    });

    subpageTextNodes.forEach((el) => subpageTextObserver.observe(el));
  }

  function onSubpageScroll() {
    if (stackingRafId) return;
    stackingRafId = requestAnimationFrame(() => {
      handleStickyStacking();
      updateSubpageTextBlur();
      stackingRafId = null;
    });
  }

  if (scrollWrap) {
    scrollWrap.addEventListener('scroll', onSubpageScroll, { passive: true });
  }

  // Smooth High-Performance Animation Engine for Subpage Scrolling
  let activeScrollAnimId = null;

  function smoothScrollSubpageTo(targetY, duration = 450) {
    if (!scrollWrap) return;
    if (activeScrollAnimId) {
      cancelAnimationFrame(activeScrollAnimId);
      activeScrollAnimId = null;
    }
    const startY = scrollWrap.scrollTop;
    const maxScroll = Math.max(0, scrollWrap.scrollHeight - scrollWrap.clientHeight);
    const clampedTarget = Math.max(0, Math.min(targetY, maxScroll));
    const deltaY = clampedTarget - startY;
    if (Math.abs(deltaY) < 2) {
      scrollWrap.scrollTop = clampedTarget;
      handleStickyStacking();
      return;
    }
    const startTime = performance.now();

    function step(now) {
      const elapsed = now - startTime;
      const progress = Math.min(elapsed / duration, 1);
      const ease = progress < 0.5 
        ? 4 * progress * progress * progress 
        : 1 - Math.pow(-2 * progress + 2, 3) / 2;
      
      scrollWrap.scrollTop = startY + deltaY * ease;
      handleStickyStacking();

      if (progress < 1) {
        activeScrollAnimId = requestAnimationFrame(step);
      } else {
        activeScrollAnimId = null;
      }
    }
    activeScrollAnimId = requestAnimationFrame(step);
  }

  // Wire up all internal anchor links within subpage for smooth subpage container scrolling
  if (scrollWrap) {
    const subpageAnchors = scrollWrap.querySelectorAll('a[href^="#"]');
    subpageAnchors.forEach((anchor) => {
      anchor.addEventListener('click', (e) => {
        const hash = anchor.getAttribute('href');
        if (!hash || hash === '#') return;
        const targetEl = scrollWrap.querySelector(hash);
        if (targetEl) {
          e.preventDefault();
          const wrapRect = scrollWrap.getBoundingClientRect();
          const targetRect = targetEl.getBoundingClientRect();
          const targetTop = scrollWrap.scrollTop + (targetRect.top - wrapRect.top) - 70;
          smoothScrollSubpageTo(targetTop, 500);
        }
      });
    });
  }

  // Interactive DesignForge Prompt Presets
  const presetChips = document.querySelectorAll('.df-preset-chip');
  const promptInput = document.querySelector('.df-input-value');
  const promptBox = document.querySelector('.df-studio-input-box');

  presetChips.forEach((chip) => {
    chip.addEventListener('click', () => {
      const text = chip.textContent.trim().replace(/^["']|["']$/g, '');
      if (promptInput) {
        promptInput.textContent = `"${text}"`;
      }
      if (promptBox) {
        promptBox.style.borderColor = 'rgba(204, 255, 0, 0.8)';
        promptBox.style.boxShadow = '0 0 20px rgba(204, 255, 0, 0.35)';
        setTimeout(() => {
          promptBox.style.borderColor = '';
          promptBox.style.boxShadow = '';
        }, 800);
      }
    });
  });

  // Interactive DesignForge Mode Pills
  const modePills = document.querySelectorAll('.df-mode-pill');
  modePills.forEach((mode) => {
    mode.addEventListener('click', () => {
      mode.classList.toggle('active');
    });
  });
}


/* ============================================
   CREATION HANDS ASCII MOTION CANVAS ENGINE
   Renders the Robot Hand (left) and Human Hand (right)
   as dynamic, living ASCII character matrix particles
   touching the centered black glass folder file.
   ============================================ */
function initFeaturedAsciiMotion() {
  const canvas = document.getElementById('featured-ascii-canvas');
  const folder = document.getElementById('featured-glass-file');
  const container = document.querySelector('.featured-file-center-wrap');
  if (!canvas || !folder || !container) return;

  const ctx = canvas.getContext('2d', { alpha: true });
  if (!ctx) return;

  // Monospace ASCII character density sets
  const ASCII_CYBER = " .:+*10#%@";
  const ASCII_HUMAN = " .,:;+*?S#@";

  const img = new Image();
  img.crossOrigin = 'anonymous';
  img.src = 'assets/images/creation_hands_art.jpg';

  let imgLoaded = false;
  let leftPixels = null;
  let rightPixels = null;
  let leftW = 0, leftH = 0;
  let rightW = 0, rightH = 0;

  img.onload = () => {
    const imgWidth = img.naturalWidth || img.width;
    const imgHeight = img.naturalHeight || img.height;

    // Left hand spans x: 0% to 48.5%
    // Right hand spans x: 50.5% to 100%
    const splitLeftW = Math.floor(imgWidth * 0.485);
    const splitRightX = Math.floor(imgWidth * 0.505);
    const splitRightW = imgWidth - splitRightX;

    // Buffer for Left Robot Hand
    leftW = splitLeftW;
    leftH = imgHeight;
    const cLeft = document.createElement('canvas');
    cLeft.width = leftW;
    cLeft.height = leftH;
    const ctxLeft = cLeft.getContext('2d', { willReadFrequently: true });
    ctxLeft.drawImage(img, 0, 0, leftW, leftH, 0, 0, leftW, leftH);
    leftPixels = ctxLeft.getImageData(0, 0, leftW, leftH);

    // Buffer for Right Human Hand
    rightW = splitRightW;
    rightH = imgHeight;
    const cRight = document.createElement('canvas');
    cRight.width = rightW;
    cRight.height = rightH;
    const ctxRight = cRight.getContext('2d', { willReadFrequently: true });
    ctxRight.drawImage(img, splitRightX, 0, rightW, rightH, 0, 0, rightW, rightH);
    rightPixels = ctxRight.getImageData(0, 0, rightW, rightH);

    imgLoaded = true;
    resize();
  };

  let width = 0;
  let height = 0;
  let mouseX = -9999;
  let mouseY = -9999;
  let isHovering = false;
  let time = 0;

  function resize() {
    const dpr = Math.min(window.devicePixelRatio || 1, 2);
    width = window.innerWidth;
    height = Math.max(container.offsetHeight, 520);

    canvas.width = width * dpr;
    canvas.height = height * dpr;
    canvas.style.width = `${width}px`;
    canvas.style.height = `${height}px`;
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  }

  window.addEventListener('resize', resize);

  container.addEventListener('mousemove', (e) => {
    const rect = canvas.getBoundingClientRect();
    mouseX = e.clientX - rect.left;
    mouseY = e.clientY - rect.top;
    isHovering = true;
  });

  container.addEventListener('mouseleave', () => {
    mouseX = -9999;
    mouseY = -9999;
    isHovering = false;
  });

  function render() {
    time += 0.038;
    ctx.clearRect(0, 0, width, height);

    if (imgLoaded && leftPixels && rightPixels && width > 0) {
      const folderRect = folder.getBoundingClientRect();
      const canvasRect = canvas.getBoundingClientRect();

      // Folder bounds relative to full-viewport canvas
      const folderLeft = folderRect.left - canvasRect.left;
      const folderRight = folderRect.right - canvasRect.left;
      const folderCenterY = (folderRect.top + folderRect.bottom) / 2 - canvasRect.top;
      const folderHeight = folderRect.height;

      // Character grid size for high-density ASCII rendering
      const charSize = width < 768 ? 6 : 7.2;
      const fontHeight = charSize * 1.05;

      ctx.font = `700 ${charSize}px "Courier New", "Consolas", monospace`;
      ctx.textAlign = 'center';
      ctx.textBaseline = 'middle';

      // Hand dimensions: make hands majestic and extend completely to screen edges
      const handHeight = Math.max(folderHeight * 1.35, 380);
      
      // Left Robot Hand: extends from beyond left screen edge (x <= 0) to touch folder left edge
      const targetLeftX = folderLeft + 8;
      const naturalLeftW = handHeight * (leftW / leftH);
      const handLeftWidth = Math.max(folderLeft + 160, naturalLeftW);
      const leftStartX = targetLeftX - handLeftWidth;
      const leftStartY = folderCenterY - handHeight * 0.36;

      // Right Human Hand: extends from folder right edge all the way beyond right screen edge (x >= width)
      const targetRightX = folderRight - 8;
      const naturalRightW = handHeight * (rightW / rightH);
      const handRightWidth = Math.max((width - folderRight) + 160, naturalRightW);
      const rightStartX = targetRightX;
      const rightStartY = folderCenterY - handHeight * 0.36;

      // Draw Left Robot Hand in ASCII Motion
      drawHandAscii(
        leftPixels, leftW, leftH,
        leftStartX, leftStartY, handLeftWidth, handHeight,
        charSize, fontHeight,
        ASCII_CYBER,
        true,
        time
      );

      // Draw Right Human Hand in ASCII Motion
      drawHandAscii(
        rightPixels, rightW, rightH,
        rightStartX, rightStartY, handRightWidth, handHeight,
        charSize, fontHeight,
        ASCII_HUMAN,
        false,
        time + 1.8
      );
    }

    requestAnimationFrame(render);
  }

  function drawHandAscii(pixelData, pW, pH, startX, startY, drawW, drawH, stepX, stepY, charSet, isRobot, t) {
    const raw = pixelData.data;
    const cols = Math.floor(drawW / stepX);
    const rows = Math.floor(drawH / stepY);

    for (let r = 0; r < rows; r++) {
      const y = startY + r * stepY;
      if (y < -20 || y > height + 20) continue;

      const normY = r / rows;
      const imgY = Math.min(pH - 1, Math.max(0, Math.floor(normY * pH)));

      for (let c = 0; c < cols; c++) {
        const x = startX + c * stepX;
        if (x < -20 || x > width + 20) continue;

        const normX = c / cols;
        const imgX = Math.min(pW - 1, Math.max(0, Math.floor(normX * pW)));

        const idx = (imgY * pW + imgX) * 4;
        const red = raw[idx];
        const green = raw[idx + 1];
        const blue = raw[idx + 2];
        const alpha = raw[idx + 3];

        // Background is pure white / near white (brightness > 235)
        const brightness = red * 0.299 + green * 0.587 + blue * 0.114;
        if (brightness > 238 || alpha < 30) continue;

        // Density value: 0 (light) to 1 (dense dark ink)
        const densityVal = (255 - brightness) / 255;
        if (densityVal < 0.07) continue;

        // Dynamic ASCII motion wave & shimmer
        const wave = Math.sin(c * 0.16 + r * 0.12 + t * 2.4);
        const noise = Math.sin(c * 97.3 + r * 43.1 + t * 3.8);

        // Mouse proximity interaction (wave ripple)
        let mouseBoost = 0;
        if (isHovering) {
          const dx = x - mouseX;
          const dy = y - mouseY;
          const mouseDist = Math.sqrt(dx * dx + dy * dy);
          if (mouseDist < 140) {
            mouseBoost = (1 - mouseDist / 140) * 0.35;
          }
        }

        // Modulate character density index with motion
        const charIdxFloat = (densityVal + mouseBoost + wave * 0.08 + noise * 0.04) * (charSet.length - 1);
        const charIdx = Math.max(1, Math.min(charSet.length - 1, Math.round(charIdxFloat)));
        const ch = charSet[charIdx] || '.';

        // Stylize character color
        const charAlpha = Math.min(1, 0.45 + densityVal * 0.55 + mouseBoost);

        if (isRobot) {
          if (densityVal > 0.6 && (c + r) % 5 === 0) {
            ctx.fillStyle = `rgba(14, 116, 144, ${charAlpha})`; // Cyan accent
          } else {
            ctx.fillStyle = `rgba(15, 23, 42, ${charAlpha})`; // Dark graphite
          }
        } else {
          if (densityVal > 0.65 && (c + r) % 6 === 0) {
            ctx.fillStyle = `rgba(71, 85, 105, ${charAlpha})`; // Slate accent
          } else {
            ctx.fillStyle = `rgba(15, 23, 42, ${charAlpha})`; // Dark ink
          }
        }

        ctx.fillText(ch, x, y);
      }
    }
  }

  requestAnimationFrame(render);
}

/* ============================================
   APPLICATION STARTUP (INSTANT LOAD WITHOUT PRELOADER OVERLAY)
   ============================================ */
document.addEventListener('DOMContentLoaded', () => {
  if ('scrollRestoration' in history) {
    history.scrollRestoration = 'manual';
  }

  document.body.classList.add('is-loaded');

  initViewProjectCursor();
  initClock();
  initHorizontalSliceGlitch();
  initInfiniteMarquees();
  initScrollAnimations();
  initAboutDraggableObject();
  initFeaturedAsciiMotion();
  initFeaturedProjectsSubpage();
  initIdentitySection();
  initDoubleTapCursor();
  initSubPage();

  if (window.lucide && typeof window.lucide.createIcons === 'function') {
    window.lucide.createIcons();
  }
});



