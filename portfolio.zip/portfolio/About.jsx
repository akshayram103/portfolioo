import { motion } from "framer-motion";
import { TIMELINE } from "@/data/portfolioData";

export default function About() {
  return (
    <section id="about" className="section" data-testid="about-section">
      <div className="container-x">
        <div className="grid lg:grid-cols-12 gap-14 items-start">
          {/* Left — image */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.7 }}
            className="lg:col-span-5 relative"
          >
                <div className="gradient-border overflow-hidden aspect-[4/5]">
              <img
                src="https://images.unsplash.com/photo-1524504388940-b1c1722653e1?w=1000&q=80&auto=format&fit=crop"
                alt="akshayram — Video Editor"
                className="w-full h-full object-cover"
                loading="lazy"
              />
              <div className="absolute inset-0 pointer-events-none" style={{
                background: "linear-gradient(180deg, transparent 60%, rgba(11,15,25,0.8))",
              }} />
            </div>
                <div className="absolute -bottom-6 -right-6 surface-glass p-4 flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl flex items-center justify-center" style={{ background: "linear-gradient(135deg,#00FF6A,#00C471)" }}>
                <span className="font-display font-bold text-white">A</span>
              </div>
              <div>
                <div className="text-sm font-semibold">2.5+ Years</div>
                <div className="text-xs text-slate-400">Professional editing</div>
              </div>
            </div>
          </motion.div>

          {/* Right — copy + timeline */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, margin: "-80px" }}
            transition={{ duration: 0.7, delay: 0.1 }}
            className="lg:col-span-7"
          >
            <span className="chip">About Me</span>
            <h2 className="font-display font-bold text-4xl sm:text-5xl mt-4 leading-tight">
              Storytelling <span className="text-gradient-accent">frame by frame</span>.
            </h2>
            <div className="mt-6 space-y-4 text-slate-300 leading-relaxed max-w-2xl">
              <p>
                Hi, I&apos;m <span className="text-white font-semibold">akshayram</span>, a passionate
                Video Editor with over 2.5 years of experience crafting high-quality digital content using CapCut.
              </p>
              <p>
                My expertise lies in editing <span className="text-slate-100">Instagram Reels, YouTube Shorts, promotional videos,
                advertisements, cinematic edits, travel videos and social media content</span>.
              </p>
              <p>
                I focus on storytelling, smooth transitions, engaging visuals, sound design and color grading —
                creating videos that keep audiences watching until the last second.
              </p>
            </div>

            {/* Timeline */}
            <div className="mt-12 relative pl-8">
              <div className="absolute left-2 top-2 bottom-2 w-px bg-gradient-to-b from-[#00FF6A] via-[#00C471] to-transparent" />
              <div className="space-y-8">
                {TIMELINE.map((t, i) => (
                  <motion.div
                    key={t.year}
                    initial={{ opacity: 0, x: -20 }}
                    whileInView={{ opacity: 1, x: 0 }}
                    viewport={{ once: true }}
                    transition={{ delay: i * 0.12 }}
                    className="relative"
                  >
                    <span className="timeline-dot absolute -left-[28px] top-1.5" />
                    <div className="text-xs uppercase tracking-[0.3em] text-slate-500">
                      {t.year}
                    </div>
                    <div className="font-display font-semibold text-lg text-white mt-1">
                      {t.title}
                    </div>
                    <p className="text-slate-400 text-sm mt-1 max-w-md">{t.desc}</p>
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}
