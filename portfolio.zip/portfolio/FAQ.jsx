import { motion } from "framer-motion";
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from "@/components/ui/accordion";
import { FAQS } from "@/data/portfolioData";

export default function FAQ() {
  return (
    <section id="faq" className="section" data-testid="faq-section">
      <div className="container-x">
        <div className="grid lg:grid-cols-12 gap-10">
          <div className="lg:col-span-5">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6 }}
              className="sticky top-28"
            >
              <span className="chip">FAQ</span>
              <h2 className="font-display font-bold text-4xl sm:text-5xl mt-4">
                Everything you might{" "}
                <span className="text-gradient-accent">wonder about</span>.
              </h2>
              <p className="mt-4 text-slate-400">
                Still curious? Reach out — I usually reply within a few hours.
              </p>
              <a href="#contact" className="btn-outline-accent mt-6 inline-flex">
                Ask a question
              </a>
            </motion.div>
          </div>

          <div className="lg:col-span-7">
            <Accordion type="single" collapsible className="space-y-4">
              {FAQS.map((f, i) => (
                <motion.div
                  key={f.q}
                  initial={{ opacity: 0, y: 12 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.06 }}
                >
                  <AccordionItem
                    value={`item-${i}`}
                    className="faq-item border-b-0"
                    data-testid={`faq-item-${i}`}
                  >
                    <AccordionTrigger className="text-left font-display text-lg hover:no-underline py-5">
                      {f.q}
                    </AccordionTrigger>
                    <AccordionContent className="text-slate-300 leading-relaxed pb-5">
                      {f.a}
                    </AccordionContent>
                  </AccordionItem>
                </motion.div>
              ))}
            </Accordion>
          </div>
        </div>
      </div>
    </section>
  );
}
