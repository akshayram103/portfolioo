import { motion } from "framer-motion";
import * as Icons from "lucide-react";
import { ArrowUpRight } from "lucide-react";
import { SERVICES } from "@/data/portfolioData";

export default function Services() {
  return (
    <section id="services" className="section relative" data-testid="services-section">
      <div className="orb" style={{ top: "10%", right: "-5%", width: 320, height: 320, background: "radial-gradient(circle, #00FF6A, transparent 65%)" }} />
      <div className="container-x relative">
        <div className="max-w-2xl">
          <span className="chip">Services</span>
          <h2 className="font-display font-bold text-4xl sm:text-5xl mt-4">
            Editing that <span className="text-gradient-accent">scales your reach</span>.
          </h2>
          <p className="mt-4 text-slate-400">
            Pick a service or bundle multiple — every project ships with a signature grade,
            sound design and platform-ready exports.
          </p>
        </div>

        <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {SERVICES.map((s, i) => {
            const Icon = Icons[s.icon] || Icons.Sparkles;
            return (
              <motion.article
                key={s.title}
                initial={{ opacity: 0, y: 24 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ duration: 0.5, delay: (i % 6) * 0.05 }}
                whileHover={{ y: -6 }}
                className="surface-card p-6 group relative overflow-hidden"
                data-testid={`service-card-${i}`}
              >
                <div
                  className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity"
                  style={{
                      background:
                        "radial-gradient(400px 200px at 0% 0%, rgba(0,255,106,0.14), transparent 60%)",
                    }}
                />
                <div className="relative">
                  <div
                    className="w-12 h-12 rounded-xl flex items-center justify-center mb-5"
                    style={{
                      background:
                        i % 2 === 0
                          ? "linear-gradient(135deg, rgba(0,255,106,0.25), rgba(0,255,106,0.05))"
                          : "linear-gradient(135deg, rgba(0,196,113,0.25), rgba(0,196,113,0.05))",
                      border: "1px solid rgba(255,255,255,0.08)",
                    }}
                  >
                    <Icon
                      className="w-5 h-5"
                      style={{ color: i % 2 === 0 ? "#a8ffd6" : "#66ffd1" }}
                    />
                  </div>
                  <h3 className="font-display text-lg font-semibold text-white">
                    {s.title}
                  </h3>
                  <p className="mt-2 text-sm text-slate-400 leading-relaxed">{s.desc}</p>
                  <button
                    data-testid={`service-learn-more-${i}`}
                    className="mt-5 inline-flex items-center gap-1.5 text-sm text-slate-200 hover:text-white group/link"
                  >
                    Learn more
                    <ArrowUpRight className="w-4 h-4 transition-transform group-hover/link:translate-x-0.5 group-hover/link:-translate-y-0.5" />
                  </button>
                </div>
              </motion.article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
