import { motion } from "framer-motion";
import { SOFTWARE } from "@/data/portfolioData";

/**
 * Continuous horizontal marquee of software labels.
 * Uses two duplicated tracks for a seamless loop.
 */
export default function Software() {
  const rows = [...SOFTWARE, ...SOFTWARE];

  return (
    <section className="section !py-20 relative overflow-hidden" data-testid="software-section">
      <div className="container-x">
        <div className="max-w-2xl">
          <span className="chip">Software Stack</span>
          <h2 className="font-display font-bold text-4xl sm:text-5xl mt-4">
            Tools that <span className="text-gradient-accent">power</span> the edit.
          </h2>
        </div>
      </div>

      <div className="relative mt-12">
        <div
          className="absolute inset-y-0 left-0 w-24 z-10"
          style={{
            background:
              "linear-gradient(90deg, #0b0f19 0%, rgba(11,15,25,0) 100%)",
          }}
        />
        <div
          className="absolute inset-y-0 right-0 w-24 z-10"
          style={{
            background:
              "linear-gradient(270deg, #0b0f19 0%, rgba(11,15,25,0) 100%)",
          }}
        />
        <div className="marquee-track py-4">
          {rows.map((label, i) => (
            <motion.div
              key={`${label}-${i}`}
              whileHover={{ y: -4 }}
              className="flex items-center gap-3 px-8 py-4 rounded-2xl surface-glass min-w-max"
            >
              <span
                className="h-8 w-8 rounded-lg flex items-center justify-center font-display font-bold text-white text-sm"
                style={{
                  background:
                    i % 2 === 0
                      ? "linear-gradient(135deg,#00FF6A,#00E08A)"
                      : "linear-gradient(135deg,#06b6d4,#22d3ee)",
                }}
              >
                {label.charAt(0)}
              </span>
              <span className="font-display text-lg tracking-tight text-slate-100">
                {label}
              </span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
