import { Instagram, Youtube, Linkedin, MessageCircle } from "lucide-react";
import { NAV_LINKS, SERVICES } from "@/data/portfolioData";

export default function Footer() {
  const year = new Date().getFullYear();
  const go = (id) => {
    const el = document.getElementById(id);
    if (el) el.scrollIntoView({ behavior: "smooth" });
  };
  return (
    <footer className="pt-20 pb-10 border-t border-white/5 relative" data-testid="site-footer">
      <div className="container-x">
        <div className="grid lg:grid-cols-12 gap-10">
          <div className="lg:col-span-5">
            <div className="font-display font-bold text-2xl">
              <span className="text-gradient-accent">akshayram</span>
            </div>
            <p className="mt-4 text-slate-400 max-w-md">
              Professional Video Editor · CapCut Specialist · Content Creator turning
              raw footage into scroll-stopping cinema.
            </p>
            <div className="mt-6 flex items-center gap-2">
              {[Instagram, Youtube, Linkedin, MessageCircle].map((I, i) => (
                <a
                  key={i}
                  href="#"
                  className="w-10 h-10 rounded-full flex items-center justify-center surface-glass hover:border-white/25 transition"
                  aria-label="social"
                >
                  <I className="w-4 h-4 text-slate-200" />
                </a>
              ))}
            </div>
          </div>

          <div className="lg:col-span-3">
            <div className="text-sm uppercase tracking-[0.28em] text-slate-500 mb-4">
              Quick Links
            </div>
            <ul className="space-y-2">
              {NAV_LINKS.slice(0, 6).map((l) => (
                <li key={l.id}>
                  <button
                    onClick={() => go(l.id)}
                    className="text-slate-300 hover:text-white transition"
                  >
                    {l.label}
                  </button>
                </li>
              ))}
            </ul>
          </div>

          <div className="lg:col-span-4">
            <div className="text-sm uppercase tracking-[0.28em] text-slate-500 mb-4">
              Services
            </div>
            <ul className="grid grid-cols-2 gap-y-2 gap-x-4">
              {SERVICES.slice(0, 8).map((s) => (
                <li key={s.title}>
                  <button
                    onClick={() => go("services")}
                    className="text-sm text-slate-300 hover:text-white transition text-left"
                  >
                    {s.title}
                  </button>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-white/5 flex flex-col sm:flex-row items-center justify-between gap-3 text-sm text-slate-500">
          <span>© {year} akshayram. All rights reserved.</span>
          <span>
            Designed & Developed by{" "}
            <span className="text-gradient-accent font-semibold">akshayram</span>
          </span>
        </div>
      </div>
    </footer>
  );
}
