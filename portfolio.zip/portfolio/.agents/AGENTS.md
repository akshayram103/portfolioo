# Workspace Rules

## Finishing Work Workflow
When completing any task in this workspace:
1. **Live Verification**: Always launch/verify the application on the local dev server and test interactive features.
2. **Visual Inspection**: Capture screenshots using browser tools to verify visual layout, typography, proportions, and animations.
3. **Summary & File Links**: Provide a clear, concise summary of all changes made with clickable markdown file links.
