import { motion } from "framer-motion";
import * as Icons from "lucide-react";
import { WHY_CHOOSE } from "@/data/portfolioData";

export default function WhyChooseMe() {
  return (
    <section className="section" data-testid="why-choose-section">
      <div className="container-x">
        <div className="max-w-2xl">
          <span className="chip">Why Choose Me</span>
          <h2 className="font-display font-bold text-4xl sm:text-5xl mt-4">
            The <span className="text-gradient-accent">unfair advantage</span> in your feed.
          </h2>
        </div>

        <div className="mt-14 grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {WHY_CHOOSE.map((w, i) => {
            const Icon = Icons[w.icon] || Icons.Sparkles;
            return (
              <motion.div
                key={w.title}
                initial={{ opacity: 0, y: 22 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ duration: 0.4, delay: (i % 4) * 0.08 }}
                whileHover={{ y: -6 }}
                className="surface-card p-6 group relative overflow-hidden"
              >
                <div
                  className="absolute -top-16 -right-10 w-40 h-40 rounded-full opacity-20 group-hover:opacity-40 transition-opacity"
                  style={{
                    background:
                      i % 2 === 0
                        ? "radial-gradient(circle, rgba(124,58,237,0.7), transparent 60%)"
                        : "radial-gradient(circle, rgba(6,182,212,0.6), transparent 60%)",
                  }}
                />
                <Icon className="w-6 h-6 text-white" />
                <div className="mt-6 font-display text-lg font-semibold">{w.title}</div>
                <div className="mt-2 text-xs uppercase tracking-[0.28em] text-slate-500">
                  0{i + 1}
                </div>
              </motion.div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
