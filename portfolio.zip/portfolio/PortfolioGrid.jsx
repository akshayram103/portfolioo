import { useMemo, useRef, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Play, Clock, User, Code2, ArrowUpRight } from "lucide-react";
import { PORTFOLIO_FILTERS, PORTFOLIO_ITEMS } from "@/data/portfolioData";

function VideoTile({ item, i, onOpen }) {
  const vidRef = useRef(null);
  const onEnter = () => {
    if (vidRef.current) {
      vidRef.current.currentTime = 0;
      vidRef.current.play().catch(() => {});
    }
  };
  const onLeave = () => {
    if (vidRef.current) {
      vidRef.current.pause();
    }
  };

  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.95 }}
      transition={{ duration: 0.4, delay: (i % 6) * 0.05 }}
      whileHover={{ y: -6 }}
      className="video-tile group"
      onMouseEnter={onEnter}
      onMouseLeave={onLeave}
      data-testid={`portfolio-card-${item.id}`}
    >
      <div className="relative aspect-[4/5] bg-black">
        <img src={item.thumb} alt={item.title} loading="lazy" />
        <video
          ref={vidRef}
          src={item.preview}
          muted
          loop
          playsInline
          preload="none"
          className="absolute inset-0 w-full h-full object-cover opacity-0 group-hover:opacity-100 transition-opacity duration-300"
        />
        <div className="play-badge">
          <div className="absolute top-3 left-3 chip !py-1 !px-2 !text-[10px]">
            {item.category}
          </div>
          <div className="absolute bottom-3 left-3 right-3 flex items-end justify-between gap-3">
            <div>
              <h3 className="font-display text-white font-semibold text-base leading-tight">
                {item.title}
              </h3>
              <div className="mt-1 text-xs text-slate-300 flex items-center gap-2">
                <User className="w-3 h-3" /> {item.client}
                <span className="text-slate-500">·</span>
                <Clock className="w-3 h-3" /> {item.duration}
              </div>
            </div>
            <button
              onClick={() => onOpen(item)}
              data-testid={`portfolio-open-${item.id}`}
              className="h-10 w-10 rounded-full flex items-center justify-center bg-white/10 backdrop-blur-md border border-white/20 hover:bg-white/20 transition"
              aria-label="View project"
            >
              <Play className="w-4 h-4 text-white" />
            </button>
          </div>
        </div>
      </div>
    </motion.article>
  );
}

export default function PortfolioGrid() {
  const [filter, setFilter] = useState("All");
  const [active, setActive] = useState(null);

  const filtered = useMemo(() => {
    if (filter === "All") return PORTFOLIO_ITEMS;
    return PORTFOLIO_ITEMS.filter((p) => p.category === filter);
  }, [filter]);

  return (
    <section id="portfolio" className="section" data-testid="portfolio-section">
      <div className="container-x">
        <div className="flex flex-col lg:flex-row lg:items-end lg:justify-between gap-6">
          <div className="max-w-2xl">
            <span className="chip">Portfolio</span>
            <h2 className="font-display font-bold text-4xl sm:text-5xl mt-4">
              Selected <span className="text-gradient-accent">work</span>.
            </h2>
            <p className="mt-4 text-slate-400">
              Hover any tile to preview the edit — click to open project details.
            </p>
          </div>

          {/* Filters */}
          <div className="flex flex-wrap gap-2" data-testid="portfolio-filters">
            {PORTFOLIO_FILTERS.map((f) => (
              <button
                key={f}
                data-testid={`portfolio-filter-${f.toLowerCase().replace(/\s+/g, "-")}`}
                onClick={() => setFilter(f)}
                className={`px-4 py-2 rounded-full text-sm border transition-all ${
                  filter === f
                    ? "bg-white text-black border-white"
                    : "bg-white/[0.03] text-slate-300 border-white/10 hover:border-white/25"
                }`}
              >
                {f}
              </button>
            ))}
          </div>
        </div>

        {/* Grid */}
        <motion.div
          layout
          className="mt-12 grid sm:grid-cols-2 lg:grid-cols-3 gap-5"
        >
          <AnimatePresence mode="popLayout">
            {filtered.map((item, i) => (
              <VideoTile key={item.id} item={item} i={i} onOpen={setActive} />
            ))}
          </AnimatePresence>
        </motion.div>
      </div>

      {/* Modal */}
      <AnimatePresence>
        {active && (
          <motion.div
            className="fixed inset-0 z-[80] flex items-center justify-center p-4"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={() => setActive(null)}
            data-testid="portfolio-modal"
          >
            <div className="absolute inset-0 bg-black/80 backdrop-blur-md" />
            <motion.div
              initial={{ y: 24, opacity: 0, scale: 0.98 }}
              animate={{ y: 0, opacity: 1, scale: 1 }}
              exit={{ y: 24, opacity: 0, scale: 0.98 }}
              className="relative surface-glass max-w-4xl w-full overflow-hidden"
              onClick={(e) => e.stopPropagation()}
            >
              <div className="aspect-video bg-black">
                <video
                  src={active.preview}
                  poster={active.thumb}
                  controls
                  autoPlay
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="p-6">
                <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-slate-400">
                  <span>{active.category}</span>
                  <span>·</span>
                  <span>{active.duration}</span>
                </div>
                <h3 className="font-display text-2xl font-semibold mt-2">{active.title}</h3>
                <p className="mt-3 text-slate-300">{active.description}</p>
                <div className="mt-4 flex flex-wrap gap-3 text-sm text-slate-400">
                  <span className="inline-flex items-center gap-1.5">
                    <User className="w-4 h-4" /> {active.client}
                  </span>
                  <span className="inline-flex items-center gap-1.5">
                    <Code2 className="w-4 h-4" /> {active.software}
                  </span>
                </div>
                <div className="mt-6 flex items-center justify-between">
                  <button
                    className="btn-ghost text-sm"
                    onClick={() => setActive(null)}
                    data-testid="portfolio-modal-close"
                  >
                    Close
                  </button>
                  <a
                    href="#contact"
                    onClick={() => setActive(null)}
                    className="btn-primary text-sm"
                  >
                    Start a similar project <ArrowUpRight className="w-4 h-4" />
                  </a>
                </div>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </section>
  );
}
