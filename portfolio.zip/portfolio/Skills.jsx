import { motion } from "framer-motion";
import { SKILL_GROUPS } from "@/data/portfolioData";

export default function Skills() {
  return (
    <section id="skills" className="section" data-testid="skills-section">
      <div className="container-x">
        <div className="max-w-2xl">
          <span className="chip">Skills</span>
          <h2 className="font-display font-bold text-4xl sm:text-5xl mt-4">
            A toolkit built for <span className="text-gradient-accent">retention</span>.
          </h2>
          <p className="mt-4 text-slate-400">
            Every project uses the right blend of craft, motion and story — from CapCut
            editing to AI-assisted workflows.
          </p>
        </div>

        <div className="mt-14 grid md:grid-cols-2 gap-6">
          {SKILL_GROUPS.map((group, gi) => (
            <motion.div
              key={group.title}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{ duration: 0.5, delay: gi * 0.08 }}
              className="surface-card p-7 relative overflow-hidden group"
            >
              <div
                className="absolute -top-24 -right-16 w-64 h-64 rounded-full opacity-30 group-hover:opacity-50 transition-opacity"
                style={{
                  background:
                    group.accent === "primary"
                      ? "radial-gradient(circle, rgba(124,58,237,0.5), transparent 60%)"
                      : "radial-gradient(circle, rgba(6,182,212,0.4), transparent 60%)",
                }}
              />
              <div className="relative">
                <div className="flex items-center gap-3">
                  <span
                    className="w-8 h-8 rounded-lg flex items-center justify-center text-xs font-display font-bold"
                    style={{
                      background:
                        group.accent === "primary"
                          ? "linear-gradient(135deg,#00FF6A,#00E08A)"
                          : "linear-gradient(135deg,#06b6d4,#22d3ee)",
                    }}
                  >
                    {gi + 1}
                  </span>
                  <h3 className="font-display text-xl font-semibold">{group.title}</h3>
                </div>
                <div className="mt-5 flex flex-wrap gap-2">
                  {group.items.map((item, i) => (
                    <motion.span
                      key={item}
                      initial={{ opacity: 0, y: 8 }}
                      whileInView={{ opacity: 1, y: 0 }}
                      viewport={{ once: true }}
                      transition={{ delay: 0.05 * i }}
                      className="px-3 py-1.5 rounded-full text-sm bg-white/[0.04] border border-white/10 text-slate-200 hover:border-white/25 hover:bg-white/[0.08] transition-colors"
                    >
                      {item}
                    </motion.span>
                  ))}
                </div>
              </div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
