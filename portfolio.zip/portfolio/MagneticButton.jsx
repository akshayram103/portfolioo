import { useRef } from "react";
import { motion, useMotionValue, useSpring } from "framer-motion";

/**
 * Magnetic button — subtle attraction to cursor on hover.
 */
export default function MagneticButton({ children, className = "", testid, onClick, strength = 20, as = "button", ...rest }) {
  const ref = useRef(null);
  const x = useMotionValue(0);
  const y = useMotionValue(0);
  const sx = useSpring(x, { stiffness: 200, damping: 15 });
  const sy = useSpring(y, { stiffness: 200, damping: 15 });

  const onMove = (e) => {
    const r = ref.current?.getBoundingClientRect();
    if (!r) return;
    const rx = e.clientX - (r.left + r.width / 2);
    const ry = e.clientY - (r.top + r.height / 2);
    x.set((rx / r.width) * strength);
    y.set((ry / r.height) * strength);
  };
  const reset = () => {
    x.set(0);
    y.set(0);
  };

  const Comp = motion[as] || motion.button;
  return (
    <Comp
      ref={ref}
      data-testid={testid}
      onClick={onClick}
      onPointerMove={onMove}
      onPointerLeave={reset}
      style={{ x: sx, y: sy }}
      className={className}
      {...rest}
    >
      {children}
    </Comp>
  );
}
