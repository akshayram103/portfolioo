import { useEffect, useRef } from "react";
import { motion, useInView, useMotionValue, animate } from "framer-motion";

export default function Counter({ to = 0, suffix = "", decimals = 0, duration = 2 }) {
  const ref = useRef(null);
  const inView = useInView(ref, { once: true, margin: "-40px" });
  const mv = useMotionValue(0);

  useEffect(() => {
    if (!inView) return;
    const controls = animate(mv, to, {
      duration,
      ease: "easeOut",
    });
    return controls.stop;
  }, [inView, mv, to, duration]);

  useEffect(() => {
    return mv.on("change", (v) => {
      if (ref.current) {
        ref.current.textContent =
          decimals > 0 ? v.toFixed(decimals) : Math.round(v).toString();
      }
    });
  }, [mv, decimals]);

  return (
    <motion.span>
      <span ref={ref}>{decimals > 0 ? "0.0" : "0"}</span>
      <span>{suffix}</span>
    </motion.span>
  );
}
