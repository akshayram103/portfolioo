import { useMemo, useState, useEffect } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Play, Clock, Layers, ArrowRight, Sparkles } from "lucide-react";
import Counter from "@/components/portfolio/Counter";
import VideoCard from "./VideoCard";
import VideoModal from "./VideoModal";
import VideoPlayer from "./VideoPlayer";
import {
  VIDEO_CATEGORIES,
  VIDEO_PROJECTS,
  FEATURED_VIDEO,
  VIDEO_STATS,
} from "@/data/videoProjects";

/**
 * Skeleton card shown while data is loading (below-fold projects use lazy loading).
 */
function SkeletonCard() {
  return (
    <div className="surface-glass overflow-hidden">
      <div className="aspect-video animate-pulse bg-gradient-to-br from-white/[0.05] to-white/[0.02]" />
      <div className="p-5 space-y-3">
        <div className="h-4 w-3/5 rounded-full bg-white/10 animate-pulse" />
        <div className="h-3 w-full rounded-full bg-white/[0.06] animate-pulse" />
        <div className="h-3 w-4/5 rounded-full bg-white/[0.06] animate-pulse" />
      </div>
    </div>
  );
}

export default function VideoPortfolio() {
  const [filter, setFilter] = useState("All");
  const [active, setActive] = useState(null);
  const [featuredPlaying, setFeaturedPlaying] = useState(false);
  const [ready, setReady] = useState(false);

  // Simulate a brief mount-time skeleton for polish (the grid is instant otherwise).
  useEffect(() => {
    const t = setTimeout(() => setReady(true), 350);
    return () => clearTimeout(t);
  }, []);

  const filtered = useMemo(() => {
    if (filter === "All") return VIDEO_PROJECTS;
    return VIDEO_PROJECTS.filter((p) => p.category === filter);
  }, [filter]);

  const relatedFor = (project) =>
    VIDEO_PROJECTS.filter(
      (p) => p.category === project.category && p.id !== project.id
    ).slice(0, 3);

  const openProject = (project) => {
    setFeaturedPlaying(false); // stop featured playback when opening modal
    setActive(project);
  };

  return (
    <section
      id="portfolio"
      className="section relative"
      data-testid="video-portfolio-section"
    >
      {/* Ambient orbs */}
      <div
        className="orb"
        style={{
          top: "5%",
          left: "-6%",
          width: 320,
          height: 320,
          background: "radial-gradient(circle,#00FF6A,transparent 65%)",
        }}
      />
      <div
        className="orb"
        style={{
          bottom: "15%",
          right: "-4%",
          width: 280,
          height: 280,
          background: "radial-gradient(circle,#00C471,transparent 65%)",
        }}
      />

      <div className="container-x relative">
        {/* --------------- Section Header --------------- */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.6 }}
          className="max-w-3xl"
        >
          <span className="chip">
            <Sparkles className="w-3 h-3" /> Portfolio
          </span>
          <h2 className="font-display font-bold text-4xl sm:text-5xl lg:text-6xl mt-4 leading-[1.05]">
            Featured Video{" "}
            <span className="text-gradient-accent">Portfolio</span>.
          </h2>
          <p className="mt-5 text-slate-400 text-base sm:text-lg leading-relaxed">
            Explore a selection of my best editing projects — showcasing
            creativity, storytelling, smooth transitions, color grading, motion
            graphics and high-retention social media content.
          </p>
        </motion.div>

        {/* --------------- Featured Project --------------- */}
        <motion.article
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.7, delay: 0.1 }}
          className="mt-14 grid lg:grid-cols-12 gap-6"
          data-testid="video-featured"
        >
          {/* Player */}
          <div className="lg:col-span-8">
            <div className="gradient-border overflow-hidden aspect-video relative">
              {featuredPlaying ? (
                <VideoPlayer
                  src={FEATURED_VIDEO.videoUrl}
                  poster={FEATURED_VIDEO.thumbnail}
                  autoPlay
                  muted={false}
                  title={FEATURED_VIDEO.title}
                />
              ) : (
                <button
                  type="button"
                  onClick={() => setFeaturedPlaying(true)}
                  data-testid="video-featured-play"
                  className="absolute inset-0 group"
                  aria-label="Play featured project"
                >
                  <img
                    src={FEATURED_VIDEO.thumbnail}
                    alt={FEATURED_VIDEO.title}
                    loading="lazy"
                    className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                  />
                  <div
                    className="absolute inset-0"
                    style={{
                      background:
                        "linear-gradient(180deg, transparent 45%, rgba(11,15,25,0.85))",
                    }}
                  />
                  {/* Center play */}
                  <motion.span
                    whileHover={{ scale: 1.08 }}
                    className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 h-20 w-20 rounded-full flex items-center justify-center"
                    style={{
                      background:
                        "linear-gradient(135deg, rgba(124,58,237,0.95), rgba(6,182,212,0.95))",
                      boxShadow: "0 14px 60px rgba(124,58,237,0.55)",
                    }}
                  >
                    <Play className="w-8 h-8 text-white pl-1" />
                  </motion.span>
                  {/* Bottom overlay label */}
                  <div className="absolute left-6 right-6 bottom-6 flex items-end justify-between gap-4">
                    <div>
                      <div className="text-xs uppercase tracking-[0.28em] text-slate-300">
                        Featured Project
                      </div>
                      <div className="mt-2 font-display font-semibold text-white text-2xl md:text-3xl">
                        {FEATURED_VIDEO.title}
                      </div>
                    </div>
                    <div className="hidden sm:flex flex-col items-end gap-1 text-xs text-slate-300">
                      <span className="inline-flex items-center gap-1.5">
                        <Clock className="w-3.5 h-3.5" /> {FEATURED_VIDEO.duration}
                      </span>
                      <span className="inline-flex items-center gap-1.5">
                        <Layers className="w-3.5 h-3.5" /> {FEATURED_VIDEO.software}
                      </span>
                    </div>
                  </div>
                </button>
              )}
            </div>
          </div>

          {/* Details */}
          <div className="lg:col-span-4 flex flex-col gap-4">
            <div className="surface-card p-6">
              <div className="text-xs uppercase tracking-[0.28em] text-slate-500">
                Featured Project
              </div>
              <h3 className="font-display text-2xl font-semibold mt-2">
                {FEATURED_VIDEO.title}
              </h3>
              <p className="mt-3 text-sm text-slate-300 leading-relaxed">
                {FEATURED_VIDEO.description}
              </p>
              <div className="mt-4 flex flex-wrap gap-3 text-xs text-slate-400">
                <span className="inline-flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5" /> {FEATURED_VIDEO.duration}
                </span>
                <span className="inline-flex items-center gap-1.5">
                  <Layers className="w-3.5 h-3.5" /> {FEATURED_VIDEO.software}
                </span>
                <span>· {FEATURED_VIDEO.completionDate}</span>
              </div>
              <div className="mt-5 flex flex-wrap gap-1.5">
                {FEATURED_VIDEO.tags.map((t) => (
                  <span
                    key={t}
                    className="px-2 py-0.5 rounded-full text-[11px] bg-white/[0.05] border border-white/10 text-slate-300"
                  >
                    {t}
                  </span>
                ))}
              </div>
              <button
                onClick={() => openProject(FEATURED_VIDEO)}
                data-testid="video-featured-watch-now"
                className="btn-primary mt-6 w-full justify-center"
              >
                <Play className="w-4 h-4" /> Watch Now
              </button>
            </div>
            <div className="surface-glass p-6">
              <div className="text-xs uppercase tracking-[0.28em] text-slate-500">
                Editing Highlights
              </div>
              <ul className="mt-3 space-y-2 text-sm text-slate-200">
                {FEATURED_VIDEO.highlights.map((h) => (
                  <li key={h} className="flex items-start gap-2">
                    <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-gradient-to-r from-[#00FF6A] to-[#00C471]" />
                    {h}
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </motion.article>

        {/* --------------- Video Statistics --------------- */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.6, delay: 0.15 }}
          className="mt-16 surface-glass p-6 md:p-8"
          data-testid="video-stats"
        >
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {VIDEO_STATS.map((s, i) => (
              <div key={s.label} className="text-center md:text-left">
                <div className="font-display text-3xl sm:text-4xl font-extrabold text-gradient">
                  <Counter
                    to={s.value}
                    suffix={s.suffix}
                    decimals={s.decimals || 0}
                  />
                </div>
                <div className="mt-1 text-[11px] uppercase tracking-[0.28em] text-slate-400">
                  {s.label}
                </div>
              </div>
            ))}
          </div>
        </motion.div>

        {/* --------------- Filters --------------- */}
        <div className="mt-14 flex items-end justify-between flex-wrap gap-4">
          <div>
            <div className="text-xs uppercase tracking-[0.28em] text-slate-500">
              Browse
            </div>
            <h3 className="font-display text-2xl sm:text-3xl font-semibold mt-2">
              Every project, ready to press play.
            </h3>
          </div>
          <div
            className="flex flex-wrap gap-2 max-w-full overflow-x-auto"
            data-testid="video-filters"
          >
            {VIDEO_CATEGORIES.map((c) => {
              const activeChip = filter === c;
              return (
                <button
                  key={c}
                  onClick={() => setFilter(c)}
                  data-testid={`video-filter-${c
                    .toLowerCase()
                    .replace(/\s+/g, "-")}`}
                  className={`px-4 py-2 rounded-full text-sm border whitespace-nowrap transition-all ${
                    activeChip
                      ? "bg-white text-black border-white shadow-[0_6px_20px_rgba(255,255,255,0.15)]"
                      : "bg-white/[0.03] text-slate-300 border-white/10 hover:border-white/25"
                  }`}
                >
                  {c}
                </button>
              );
            })}
          </div>
        </div>

        {/* --------------- Grid --------------- */}
        <motion.div
          layout
          className="mt-10 grid sm:grid-cols-2 lg:grid-cols-3 gap-6"
          data-testid="video-grid"
        >
          {!ready
            ? Array.from({ length: 6 }).map((_, i) => <SkeletonCard key={i} />)
            : (
              <AnimatePresence mode="popLayout">
                {filtered.map((project, i) => (
                  <VideoCard
                    key={project.id}
                    project={project}
                    index={i}
                    onOpen={openProject}
                  />
                ))}
              </AnimatePresence>
            )}
        </motion.div>

        {/* Empty state */}
        {ready && filtered.length === 0 && (
          <div className="mt-10 text-center text-slate-400">
            No projects in this category yet — try another filter.
          </div>
        )}

        {/* Bottom CTA */}
        <div className="mt-14 flex justify-center">
          <a
            href="#contact"
            className="btn-outline-accent"
            data-testid="video-portfolio-cta"
          >
            Start a project with me <ArrowRight className="w-4 h-4" />
          </a>
        </div>
      </div>

      {/* --------------- Modal --------------- */}
      <AnimatePresence>
        {active && (
          <VideoModal
            project={active}
            related={relatedFor(active)}
            onClose={() => setActive(null)}
            onOpen={openProject}
          />
        )}
      </AnimatePresence>
    </section>
  );
}
