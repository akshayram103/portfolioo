/**
 * Universal video player. Detects the provider from the URL and renders:
 *   - YouTube  → iframe with autoplay/mute options
 *   - Vimeo    → iframe
 *   - GDrive   → iframe (/preview endpoint)
 *   - MP4      → native <video>
 *
 * Props:
 *   src        – video URL (any supported provider)
 *   poster     – thumbnail shown before playback for MP4 or when lazy
 *   autoPlay   – whether the video should start playing on mount (default false)
 *   muted      – muted attribute (default true, required for YT autoplay)
 *   controls   – show controls (default true)
 *   className  – wrapper classes
 *   title      – accessible title
 */
export default function VideoPlayer({
  src,
  poster,
  autoPlay = false,
  muted = true,
  controls = true,
  className = "",
  title = "Video",
}) {
  const provider = detectProvider(src);

  if (provider === "youtube") {
    const id = extractYouTubeId(src);
    const params = new URLSearchParams({
      autoplay: autoPlay ? "1" : "0",
      mute: muted ? "1" : "0",
      rel: "0",
      modestbranding: "1",
      playsinline: "1",
      controls: controls ? "1" : "0",
    });
    return (
      <iframe
        title={title}
        src={`https://www.youtube.com/embed/${id}?${params.toString()}`}
        className={`w-full h-full ${className}`}
        style={{ border: 0 }}
        allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share"
        allowFullScreen
        loading="lazy"
      />
    );
  }

  if (provider === "vimeo") {
    const id = extractVimeoId(src);
    const params = new URLSearchParams({
      autoplay: autoPlay ? "1" : "0",
      muted: muted ? "1" : "0",
      title: "0",
      byline: "0",
      portrait: "0",
    });
    return (
      <iframe
        title={title}
        src={`https://player.vimeo.com/video/${id}?${params.toString()}`}
        className={`w-full h-full ${className}`}
        style={{ border: 0 }}
        allow="autoplay; fullscreen; picture-in-picture"
        allowFullScreen
        loading="lazy"
      />
    );
  }

  if (provider === "gdrive") {
    const id = extractGDriveId(src);
    return (
      <iframe
        title={title}
        src={`https://drive.google.com/file/d/${id}/preview`}
        className={`w-full h-full ${className}`}
        style={{ border: 0 }}
        allow="autoplay; fullscreen"
        allowFullScreen
        loading="lazy"
      />
    );
  }

  // Native MP4 fallback
  return (
    <video
      src={src}
      poster={poster}
      className={`w-full h-full object-cover ${className}`}
      controls={controls}
      autoPlay={autoPlay}
      muted={muted}
      playsInline
      preload="metadata"
    />
  );
}

// --------------- Provider detection & id extraction ---------------
export function detectProvider(url = "") {
  if (!url) return "mp4";
  if (url.includes("youtube.com") || url.includes("youtu.be")) return "youtube";
  if (url.includes("vimeo.com")) return "vimeo";
  if (url.includes("drive.google.com")) return "gdrive";
  return "mp4";
}

function extractYouTubeId(url) {
  try {
    const u = new URL(url);
    if (u.hostname.includes("youtu.be")) return u.pathname.slice(1);
    if (u.searchParams.get("v")) return u.searchParams.get("v");
    // Also handle /embed/ID
    const parts = u.pathname.split("/");
    return parts[parts.length - 1];
  } catch {
    return "";
  }
}

function extractVimeoId(url) {
  try {
    const u = new URL(url);
    const parts = u.pathname.split("/").filter(Boolean);
    return parts[parts.length - 1];
  } catch {
    return "";
  }
}

function extractGDriveId(url) {
  const m = url.match(/\/d\/([a-zA-Z0-9_-]+)/);
  return m ? m[1] : "";
}
