import { useEffect } from "react";
import { motion } from "framer-motion";
import { X, User, Calendar, Layers, Clock, Share2, Tag, ArrowRight } from "lucide-react";
import { toast } from "sonner";
import VideoPlayer from "./VideoPlayer";

export default function VideoModal({ project, related = [], onClose, onOpen }) {
  useEffect(() => {
    const onKey = (e) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", onKey);
    document.body.style.overflow = "hidden";
    return () => {
      window.removeEventListener("keydown", onKey);
      document.body.style.overflow = "";
    };
  }, [onClose]);

  const share = async () => {
    const url = window.location.href.split("#")[0] + "#portfolio";
    try {
      if (navigator.share) {
        await navigator.share({ title: project.title, url });
      } else {
        await navigator.clipboard.writeText(url);
        toast.success("Link copied");
      }
    } catch {
      /* cancelled */
    }
  };

  return (
    <motion.div
      className="fixed inset-0 z-[90] flex items-center justify-center p-4 sm:p-6"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      onClick={onClose}
      data-testid="video-modal"
    >
      <div className="absolute inset-0 bg-black/85 backdrop-blur-lg" />
      <motion.div
        initial={{ scale: 0.96, y: 20, opacity: 0 }}
        animate={{ scale: 1, y: 0, opacity: 1 }}
        exit={{ scale: 0.96, y: 20, opacity: 0 }}
        transition={{ type: "spring", stiffness: 220, damping: 26 }}
        className="relative w-full max-w-6xl max-h-[92vh] overflow-y-auto surface-glass"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close */}
        <button
          onClick={onClose}
          aria-label="Close"
          data-testid="video-modal-close"
          className="absolute top-4 right-4 z-10 h-10 w-10 rounded-full flex items-center justify-center bg-black/50 backdrop-blur-md border border-white/15 hover:bg-black/80 transition"
        >
          <X className="w-5 h-5 text-white" />
        </button>

        {/* Player */}
        <div className="aspect-video bg-black">
          <VideoPlayer
            src={project.videoUrl}
            poster={project.thumbnail}
            autoPlay
            muted
            title={project.title}
          />
        </div>

        {/* Body */}
        <div className="p-6 md:p-8">
          <div className="flex flex-wrap items-center gap-2 text-xs uppercase tracking-widest text-slate-400">
            <span className="chip !py-1">{project.category}</span>
            <span className="inline-flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5" /> {project.duration}
            </span>
            <span>·</span>
            <span className="inline-flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5" /> {project.completionDate}
            </span>
            {project.client && (
              <>
                <span>·</span>
                <span className="inline-flex items-center gap-1.5">
                  <User className="w-3.5 h-3.5" /> {project.client}
                </span>
              </>
            )}
            <span>·</span>
            <span className="inline-flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5" /> {project.software}
            </span>
          </div>

          <h2 className="font-display text-3xl md:text-4xl font-bold mt-4 leading-tight">
            {project.title}
          </h2>
          <p className="mt-4 text-slate-300 leading-relaxed max-w-3xl">
            {project.description}
          </p>

          {/* Highlights (featured only) */}
          {project.highlights && (
            <div className="mt-6">
              <div className="text-xs uppercase tracking-[0.28em] text-slate-500 mb-3">
                Editing Techniques
              </div>
              <ul className="grid sm:grid-cols-2 gap-2 max-w-3xl">
                {project.highlights.map((h) => (
                  <li key={h} className="flex items-start gap-2 text-sm text-slate-200">
                    <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-gradient-to-r from-[#00FF6A] to-[#00C471]" />
                    {h}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {/* Tags */}
          {project.tags?.length > 0 && (
            <div className="mt-6 flex flex-wrap gap-2 items-center">
              <Tag className="w-3.5 h-3.5 text-slate-500" />
              {project.tags.map((t) => (
                <span
                  key={t}
                  className="px-2.5 py-1 rounded-full text-xs bg-white/[0.05] border border-white/10 text-slate-300"
                >
                  {t}
                </span>
              ))}
            </div>
          )}

          {/* Actions */}
          <div className="mt-8 flex flex-wrap items-center gap-3">
            <button
              className="btn-primary text-sm"
              onClick={onClose}
              data-testid="video-modal-start-project"
            >
              Start a similar project <ArrowRight className="w-4 h-4" />
            </button>
            <button
              className="btn-ghost text-sm"
              onClick={share}
              data-testid="video-modal-share"
            >
              <Share2 className="w-4 h-4" /> Share
            </button>
          </div>

          {/* Related projects */}
          {related.length > 0 && (
            <div className="mt-10">
              <div className="text-xs uppercase tracking-[0.28em] text-slate-500 mb-4">
                Related Projects
              </div>
              <div className="grid sm:grid-cols-3 gap-3">
                {related.map((r) => (
                  <button
                    key={r.id}
                    onClick={() => onOpen(r)}
                    className="video-tile aspect-video"
                    data-testid={`video-related-${r.id}`}
                  >
                    <img src={r.thumbnail} alt={r.title} loading="lazy" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/10 to-transparent" />
                    <div className="absolute left-3 right-3 bottom-3 text-left">
                      <div className="text-[10px] uppercase tracking-widest text-slate-300">
                        {r.category}
                      </div>
                      <div className="font-display text-sm font-semibold text-white line-clamp-1">
                        {r.title}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
      </motion.div>
    </motion.div>
  );
}
