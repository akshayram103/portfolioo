import { useState } from "react";
import { motion } from "framer-motion";
import { Play, Maximize2, Share2, Clock, Layers } from "lucide-react";
import { toast } from "sonner";

/**
 * VideoCard — reusable card for a single video project.
 * To add a new project: append an entry to videoProjects.js. No card changes needed.
 */
export default function VideoCard({ project, index = 0, onOpen }) {
  const [thumbLoaded, setThumbLoaded] = useState(false);

  const share = async (e) => {
    e.stopPropagation();
      const shareData = {
      title: project.title,
      text: `${project.title} — edited by akshayram`,
      url: typeof window !== "undefined" ? window.location.href + "#portfolio" : "",
    };
    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else if (navigator.clipboard) {
        await navigator.clipboard.writeText(shareData.url);
        toast.success("Link copied to clipboard");
      }
    } catch {
      /* user cancelled */
    }
  };

  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, scale: 0.96 }}
      transition={{ duration: 0.45, delay: (index % 6) * 0.06 }}
      whileHover={{ y: -8 }}
      className="group relative surface-glass overflow-hidden cursor-pointer"
      onClick={() => onOpen(project)}
      data-testid={`video-card-${project.id}`}
    >
      {/* Glow border on hover */}
      <div
        className="pointer-events-none absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
        style={{
          boxShadow:
            "0 0 0 1px rgba(124,58,237,0.5), 0 20px 60px rgba(124,58,237,0.25), 0 0 40px rgba(6,182,212,0.18) inset",
          borderRadius: "20px",
        }}
      />

      {/* Thumbnail */}
      <div className="relative aspect-video overflow-hidden">
        {!thumbLoaded && (
          <div className="absolute inset-0 animate-pulse bg-gradient-to-br from-white/[0.04] to-white/[0.02]" />
        )}
        <img
          src={project.thumbnail}
          alt={project.title}
          loading="lazy"
          onLoad={() => setThumbLoaded(true)}
          className={`w-full h-full object-cover transition-all duration-700 group-hover:scale-110 ${
            thumbLoaded ? "opacity-100" : "opacity-0"
          }`}
        />
        <div
          className="absolute inset-0"
          style={{
            background:
              "linear-gradient(180deg, rgba(11,15,25,0) 40%, rgba(11,15,25,0.85) 100%)",
          }}
        />

        {/* Top row — category + duration */}
        <div className="absolute top-3 left-3 right-3 flex items-center justify-between">
          <span className="chip !py-1 !px-2 !text-[10px] bg-black/45 backdrop-blur-sm">
            {project.category}
          </span>
          <span className="chip !py-1 !px-2 !text-[10px] bg-black/45 backdrop-blur-sm">
            <Clock className="w-3 h-3" /> {project.duration}
          </span>
        </div>

        {/* Play badge */}
        <motion.div
          whileHover={{ scale: 1.08 }}
          className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2 h-16 w-16 rounded-full flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity duration-300"
          style={{
            background:
              "linear-gradient(135deg, rgba(124,58,237,0.92), rgba(6,182,212,0.92))",
            boxShadow: "0 12px 40px rgba(124,58,237,0.55)",
          }}
        >
          <Play className="w-6 h-6 text-white pl-1" />
        </motion.div>
      </div>

      {/* Body — always visible on mobile, slide-up highlight on hover */}
      <div className="relative p-5">
        <h3 className="font-display text-lg font-semibold text-white leading-tight">
          {project.title}
        </h3>
        <p className="mt-2 text-sm text-slate-400 leading-relaxed line-clamp-2">
          {project.description}
        </p>

        {/* Tags */}
        <div className="mt-3 flex flex-wrap gap-1.5">
          {project.tags?.slice(0, 4).map((t) => (
            <span
              key={t}
              className="px-2 py-0.5 rounded-full text-[11px] bg-white/[0.05] border border-white/10 text-slate-300"
            >
              {t}
            </span>
          ))}
        </div>

        {/* Meta row */}
        <div className="mt-4 flex items-center gap-3 text-[11px] text-slate-500">
          <span className="inline-flex items-center gap-1.5">
            <Layers className="w-3 h-3" /> {project.software}
          </span>
          <span>·</span>
          <span>{project.completionDate}</span>
        </div>

        {/* Action row */}
        <div className="mt-5 flex items-center justify-between">
          <button
            onClick={(e) => {
              e.stopPropagation();
              onOpen(project);
            }}
            data-testid={`video-fullscreen-${project.id}`}
            className="inline-flex items-center gap-1.5 text-xs text-slate-200 hover:text-white transition"
          >
            <Maximize2 className="w-3.5 h-3.5" />
            View Full Screen
          </button>
          <button
            onClick={share}
            data-testid={`video-share-${project.id}`}
            className="inline-flex items-center gap-1.5 text-xs text-slate-200 hover:text-white transition"
          >
            <Share2 className="w-3.5 h-3.5" />
            Share
          </button>
        </div>
      </div>
    </motion.article>
  );
}
