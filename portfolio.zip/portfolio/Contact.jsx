import { useState } from "react";
import { motion } from "framer-motion";
import axios from "axios";
import { toast } from "sonner";
import {
  Mail,
  Phone,
  MapPin,
  MessageCircle,
  Linkedin,
  Instagram,
  Youtube,
  Send,
  Loader2,
} from "lucide-react";

const API = `${process.env.REACT_APP_BACKEND_URL}/api`;

const empty = { name: "", email: "", phone: "", project_type: "", budget: "", message: "" };

export default function Contact() {
  const [form, setForm] = useState(empty);
  const [sending, setSending] = useState(false);

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const submit = async (e) => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) {
      toast.error("Name, email and message are required.");
      return;
    }
    try {
      setSending(true);
      await axios.post(`${API}/contact`, {
        name: form.name,
        email: form.email,
        phone: form.phone || null,
        project_type: form.project_type || null,
        budget: form.budget || null,
        message: form.message,
      });
      toast.success("Message sent — I'll be in touch within 24 hours.");
      setForm(empty);
    } catch (err) {
      const detail = err?.response?.data?.detail || "Something went wrong. Please try again.";
      toast.error(typeof detail === "string" ? detail : "Please check your details and retry.");
    } finally {
      setSending(false);
    }
  };

  const contactBlocks = [
    { Icon: Mail, label: "Email", value: "akshayram1690@gmail.com" },
    { Icon: Phone, label: "Phone", value: "+91 6382205801" },
    { Icon: MapPin, label: "Location", value: "Available worldwide · Remote" },
  ];

  return (
    <section id="contact" className="section relative" data-testid="contact-section">
      <div className="orb" style={{ top: "20%", left: "10%", width: 260, height: 260, background: "radial-gradient(circle,#00FF6A,transparent 65%)" }} />
      <div className="container-x relative">
        <div className="grid lg:grid-cols-12 gap-8">
          {/* Left column */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6 }}
            className="lg:col-span-5 space-y-6"
          >
            <span className="chip">Get In Touch</span>
            <h2 className="font-display font-bold text-4xl sm:text-5xl leading-tight">
              Let&apos;s build the <span className="text-gradient-accent">next scroll-stopper</span>.
            </h2>
            <p className="text-slate-400 max-w-md">
              Reels, ads, brand films or full content packs — tell me what you have in mind
              and I&apos;ll reply within a few hours.
            </p>

            <div className="grid sm:grid-cols-2 gap-3">
              {contactBlocks.map(({ Icon, label, value }) => (
                <div key={label} className="surface-glass p-4 flex items-start gap-3">
                  <div
                    className="w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0"
                    style={{
                      background:
                        "linear-gradient(135deg, rgba(124,58,237,0.25), rgba(6,182,212,0.15))",
                      border: "1px solid rgba(255,255,255,0.08)",
                    }}
                  >
                    <Icon className="w-4 h-4 text-white" />
                  </div>
                  <div>
                    <div className="text-xs uppercase tracking-widest text-slate-500">
                      {label}
                    </div>
                    <div className="text-sm text-slate-200 mt-0.5">{value}</div>
                  </div>
                </div>
              ))}
            </div>

            <div className="flex flex-wrap gap-2 pt-2">
              {[
                { Icon: Instagram, href: "#" },
                { Icon: Youtube, href: "#" },
                { Icon: Linkedin, href: "#" },
              ].map(({ Icon, href }, i) => (
                <a
                  key={i}
                  href={href}
                  className="w-10 h-10 rounded-full flex items-center justify-center surface-glass hover:border-white/25 transition"
                  aria-label="social"
                >
                  <Icon className="w-4 h-4 text-slate-200" />
                </a>
              ))}
            </div>
          </motion.div>

          {/* Right — form */}
          <motion.form
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.6, delay: 0.1 }}
            onSubmit={submit}
            className="lg:col-span-7 surface-glass p-6 md:p-10"
            data-testid="contact-form"
          >
            <div className="grid sm:grid-cols-2 gap-4">
              <div>
                <label className="text-xs uppercase tracking-widest text-slate-400">Name *</label>
                <input
                  className="field mt-2"
                  placeholder="Your full name"
                  value={form.name}
                  onChange={(e) => set("name", e.target.value)}
                  data-testid="contact-name-input"
                  required
                />
              </div>
              <div>
                <label className="text-xs uppercase tracking-widest text-slate-400">Email *</label>
                <input
                  type="email"
                  className="field mt-2"
                  placeholder="you@brand.com"
                  value={form.email}
                  onChange={(e) => set("email", e.target.value)}
                  data-testid="contact-email-input"
                  required
                />
              </div>
              <div>
                <label className="text-xs uppercase tracking-widest text-slate-400">Phone</label>
                <input
                  className="field mt-2"
                  placeholder="Optional"
                  value={form.phone}
                  onChange={(e) => set("phone", e.target.value)}
                  data-testid="contact-phone-input"
                />
              </div>
              <div>
                <label className="text-xs uppercase tracking-widest text-slate-400">Project Type</label>
                <select
                  className="field mt-2"
                  value={form.project_type}
                  onChange={(e) => set("project_type", e.target.value)}
                  data-testid="contact-project-select"
                >
                  <option value="">Choose one</option>
                  <option>Instagram Reel</option>
                  <option>YouTube Short</option>
                  <option>Long-form YouTube</option>
                  <option>Advertisement</option>
                  <option>Wedding Highlights</option>
                  <option>Travel Cinematic</option>
                  <option>Podcast Editing</option>
                  <option>Other</option>
                </select>
              </div>
              <div className="sm:col-span-2">
                <label className="text-xs uppercase tracking-widest text-slate-400">Budget</label>
                <div className="grid grid-cols-4 gap-2 mt-2">
                  {["< ₹16,000", "₹16,000–₹40,000", "₹40,000–₹80,000", "₹80,000+"].map((b) => (
                    <button
                      type="button"
                      key={b}
                      onClick={() => set("budget", b)}
                      data-testid={`contact-budget-${b}`}
                      className={`px-3 py-2 rounded-xl text-sm border transition ${
                        form.budget === b
                          ? "bg-white text-black border-white"
                          : "bg-white/[0.03] text-slate-300 border-white/10 hover:border-white/25"
                      }`}
                    >
                      {b}
                    </button>
                  ))}
                </div>
              </div>
              <div className="sm:col-span-2">
                <label className="text-xs uppercase tracking-widest text-slate-400">Message *</label>
                <textarea
                  rows={5}
                  className="field mt-2 resize-none"
                  placeholder="Tell me about your project, timeline, and platform..."
                  value={form.message}
                  onChange={(e) => set("message", e.target.value)}
                  data-testid="contact-message-input"
                  required
                />
              </div>
            </div>

            <div className="mt-8 flex flex-wrap items-center gap-3">
              <button
                type="submit"
                disabled={sending}
                className="btn-primary disabled:opacity-60"
                data-testid="contact-submit-btn"
              >
                {sending ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" /> Sending...
                  </>
                ) : (
                  <>
                    Send Message <Send className="w-4 h-4" />
                  </>
                )}
              </button>
              <a href="#" className="btn-outline-accent" data-testid="contact-hire-btn">
                Hire Me <MessageCircle className="w-4 h-4" />
              </a>
            </div>
          </motion.form>
        </div>
      </div>
    </section>
  );
}
