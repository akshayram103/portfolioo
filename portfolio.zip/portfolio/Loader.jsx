import { AnimatePresence, motion } from "framer-motion";

export default function Loader({ show }) {
  return (
    <AnimatePresence>
      {show && (
        <motion.div
          data-testid="site-loader"
          initial={{ opacity: 1 }}
          exit={{ opacity: 0 }}
          transition={{ duration: 0.6, ease: "easeInOut" }}
          className="fixed inset-0 z-[100] flex flex-col items-center justify-center"
          style={{ background: "#0b0f19" }}
        >
          <div className="reel-loader" />
          <motion.p
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            className="mt-6 font-display text-sm tracking-[0.4em] uppercase text-gradient-accent"
          >
            akshayram
          </motion.p>
          <motion.p
            initial={{ opacity: 0 }}
            animate={{ opacity: 0.6 }}
            transition={{ delay: 0.4 }}
            className="mt-2 text-xs uppercase tracking-[0.3em] text-slate-500"
          >
            Rendering the reel...
          </motion.p>
        </motion.div>
      )}
    </AnimatePresence>
  );
}
