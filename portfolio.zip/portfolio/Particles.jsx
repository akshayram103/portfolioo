import { useMemo } from "react";

export default function Particles({ count = 20 }) {
  const items = useMemo(
    () =>
      Array.from({ length: count }).map((_, i) => ({
        id: i,
        left: Math.random() * 100,
        delay: Math.random() * -20,
        duration: 12 + Math.random() * 14,
        size: 1 + Math.random() * 3,
      })),
    [count]
  );
  return (
    <div aria-hidden className="fixed inset-0 pointer-events-none z-[1]">
      {items.map((p) => (
        <span
          key={p.id}
          className="particle"
          style={{
            left: `${p.left}%`,
            animationDelay: `${p.delay}s`,
            animationDuration: `${p.duration}s`,
            width: `${p.size}px`,
            height: `${p.size}px`,
          }}
        />
      ))}
    </div>
  );
}
