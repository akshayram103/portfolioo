import { motion } from "framer-motion";
import { Instagram, Youtube, Linkedin, MessageCircle } from "lucide-react";

const items = [
  { icon: Instagram, href: "#", label: "Instagram" },
  { icon: Youtube, href: "#", label: "YouTube" },
  { icon: Linkedin, href: "#", label: "LinkedIn" },
];

export default function FloatingSocial() {
  return (
    <motion.aside
      initial={{ opacity: 0, x: -20 }}
      animate={{ opacity: 1, x: 0 }}
      transition={{ delay: 1.6, duration: 0.6 }}
      className="hidden lg:flex fixed left-6 bottom-1/3 z-40 flex-col gap-3"
      data-testid="floating-socials"
    >
      {items.map(({ icon: Icon, href, label }) => (
        <motion.a
          key={label}
          href={href}
          aria-label={label}
          whileHover={{ scale: 1.12, x: 4 }}
          transition={{ type: "spring", stiffness: 260, damping: 18 }}
          className="w-10 h-10 rounded-full flex items-center justify-center surface-glass hover:border-white/25"
          style={{ boxShadow: "0 8px 24px rgba(0,0,0,0.35)" }}
        >
          <Icon className="w-4 h-4 text-slate-200" />
        </motion.a>
      ))}
      <div className="w-px h-16 mx-auto bg-gradient-to-b from-white/40 to-transparent" />
    </motion.aside>
  );
}
